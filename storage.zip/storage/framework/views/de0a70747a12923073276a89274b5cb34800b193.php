

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<!-- Modal-->
<div class="modal fade" id="modalGrupo" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">FORMULARIO DE GRUPO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('Grupo/agregarRaza')); ?>" method="POST" id="formulario-razas-grupos">
                	<?php echo csrf_field(); ?>
                	<div class="row">
                		<div class="col-md-12">
                			<div class="form-group">
                			    <label for="exampleInputPassword1">Nombre de la Raza
                			    <span class="text-danger">*</span></label>
                			    <input type="hidden" class="form-control" id="grupo_id" name="grupo_id" value="<?php echo e($gruposRazas[0]->grupos->id); ?>"/>
								<select class="form-control select2" id="raza_id" name="raza_id">
									<?php $__empty_1 = true; $__currentLoopData = $razas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
										<option value="<?php echo e($r->id); ?>"><?php echo e($r->nombre); ?> <?php echo e($r->descripcion); ?></option>                                    
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
										
									<?php endif; ?>
								</select>
                			</div>
                		</div>
                	</div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-light-dark font-weight-bold" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-sm btn-success font-weight-bold" onclick="agregar()">Agregar</button>
            </div>
        </div>
    </div>
</div>


	<!--begin::Card-->
	<div class="card card-custom gutter-b">
		<div class="card-header flex-wrap py-3">
			<div class="card-title">
				<h3 class="card-label">RAZAS DEL <?php echo e($gruposRazas[0]->grupos->nombre); ?>

				</h3>
			</div>
			<div class="card-toolbar">
				<!--begin::Button-->
				<a href="#" class="btn btn-primary font-weight-bolder" onclick="nuevo()">
					<i class="fa fa-plus-square"></i> AGREGAR UNA NUEVA RAZA AL <?php echo e($gruposRazas[0]->grupos->nombre); ?>

				</a>
				<!--end::Button-->
			</div>
		</div>
		
		<div class="card-body">
			<!--begin: Datatable-->
			<div class="table-responsive m-t-40">
				<table class="table table-bordered table-hover table-striped" id="tabla-insumos">
					<thead>
						<tr>
							<th>ID</th>
							<th>Nombre</th>
							<th>Descripcion</th>
							<th>Acciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $gruposRazas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($ra->razas->id); ?></td>
								<td><?php echo e($ra->razas->nombre); ?></td>
								<td><?php echo e($ra->razas->descripcion); ?></td>
								<td>
									<button type="button" class="btn btn-sm btn-icon btn-danger" onclick="elimina('<?php echo e($ra->id); ?>', '<?php echo e($ra->razas->nombre); ?>', '<?php echo e($ra->grupos->id); ?>')">
										<i class="flaticon2-cross"></i>
									</button>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<h3 class="text-danger">NO EXISTEN GRUPOS</h3>
						<?php endif; ?>
					</tbody>
					<tbody>
					</tbody>
				</table>
			</div>
			<!--end: Datatable-->
		</div>
	</div>
	<!--end::Card-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
    <script type="text/javascript">

    	$(function () {
    	    $('#tabla-insumos').DataTable({
    	        language: {
    	            url: '<?php echo e(asset('datatableEs.json')); ?>',
    	        },
				order: [[ 0, "desc" ]]
    	    });

    	});

    	function nuevo()
    	{
    		$("#modalGrupo").modal('show');
    	}

		function elimina(id, nombre, id_grupo)
        {
			// mostramos la pregunta en el alert
            Swal.fire({
                title: "Quieres eliminar "+nombre,
                text: "Ya no podras recuperarlo!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Si, borrar!",
                cancelButtonText: "No, cancelar!",
                reverseButtons: true
            }).then(function(result) {
				// si pulsa boton si
                if (result.value) {

                    window.location.href = "<?php echo e(url('Grupo/eliminaGrupoRaza')); ?>/"+id+"/"+id_grupo;

                    Swal.fire(
                        "Borrado!",
                        "El registro fue eliminado.",
                        "success"
                    )
                    // result.dismiss can be "cancel", "overlay",
                    // "close", and "timer"
                } else if (result.dismiss === "cancel") {
                    Swal.fire(
                        "Cancelado",
                        "La operacion fue cancelada",
                        "error"
                    )
                }
            });
        }

		$(function(){
			$('#raza_id').select2({
				placeholder: "Select a state"
			});
		});

		function agregar(){
			if($('#formulario-razas-grupos')[0].checkValidity()){
				$('#formulario-razas-grupos').submit();
				Swal.fire("Excelente!", "Registro Guardado!", "success");
			}else{
				$('#formulario-razas-grupos')[0].reportValidity()
			}
		}

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/grupos/listadoGrupoRaza.blade.php ENDPATH**/ ?>