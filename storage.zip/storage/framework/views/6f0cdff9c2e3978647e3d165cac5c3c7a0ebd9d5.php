<?php
    use \App\Http\Controllers\EventoController;
?>

<?php $__env->startSection('metadatos'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    

    

    

    <div class="row">
        <div class="col-md-12">
            
            <h2>CATEGORIA ADULTOS</h2>

            <?php
                $grupo1  = array();
                $grupo2  = array();
                $grupo3  = array();
                $grupo4  = array();
                $grupo5  = array();
                $grupo6  = array();
                $grupo7  = array();
                $grupo8  = array();
                $grupo9  = array();
                $grupo10 = array();
                $grupo11 = array();
                // dd($ejemplaresAdulto);
                foreach ($ejemplaresAdulto as $key => $e){

                    $cant = App\GrupoRaza::where('raza_id',$e->raza_id)
                                            ->first();
                    if($cant){
                        // echo ($key+1)." - Nombre Raza: ".$cant->razas->nombre." <---> Raza ID: ".$cant->razas->id." <---> Grupo ID: ".$cant->grupo_id." <---> Ejemplar ID: ".$e->ejemplar_id."<br>";
                        if($e->extrangero == 'no'){
                            $ejemplar = $e->ejemplar_id;
                        }else{
                            $ejemplar = (-1) * $e->id;
                        }
                        switch ($cant->grupo_id) {
                            case 1:
                                array_push($grupo1, "$ejemplar");
                                // echo "i equals 0";
                                break;
                            case 2:
                                array_push($grupo2, "$ejemplar");
                                // echo "i equals 1";
                                break;
                            case 3:
                                array_push($grupo3, "$ejemplar");
                                // echo "i equals 2";
                                break;
                            case 4:
                                array_push($grupo4, "$ejemplar");
                                // echo "i equals 0";
                                break;
                            case 5:
                                array_push($grupo5, "$ejemplar");
                                // echo "i equals 1";
                                break;
                            case 6:
                                array_push($grupo6, "$ejemplar");
                                // echo "i equals 2";
                                break;
                            case 7:
                                array_push($grupo7, "$ejemplar");
                                // echo "i equals 0";
                                break;
                            case 8:
                                array_push($grupo8, "$ejemplar");
                                // echo "i equals 1";
                                break;
                            case 9:
                                array_push($grupo9, "$ejemplar");
                                // echo "i equals 2";
                                break;
                            case 10:
                                array_push($grupo10, "$ejemplar");
                                // echo "i equals 2";
                                break;
                            case 11:
                                array_push($grupo11, "$ejemplar");
                                // echo "i equals 2";
                                break;
                        }
                    }
                }
                echo '<br><br>grupo I -> ';
                print_r($grupo1);
                echo '<br><br>grupo II -> ';
                print_r($grupo2);
                echo '<br><br>grupo III -> ';
                print_r($grupo3);
                echo '<br><br>grupo IV -> ';
                print_r($grupo4);
                echo '<br><br>grupo V -> ';
                print_r($grupo5);
                echo '<br><br>grupo VI -> ';
                print_r($grupo6);
                echo '<br><br>grupo VII -> ';
                print_r($grupo7);
                echo '<br><br>grupo VIII -> ';
                print_r($grupo8);
                echo '<br><br>grupo IX -> ';
                print_r($grupo9);
                echo '<br><br>grupo X -> ';
                print_r($grupo10);

            ?>
        
        <?php if(!empty($grupo5)): ?>
            <h5 class="text-primary">Grupo V</h5>
            <?php
                EventoController::armaCatalogo($grupo5, $evento->id, 5,4);
            ?>
        <?php endif; ?>
        <?php if(!empty($grupo6)): ?>
            <h5 class="text-primary">Grupo VI</h5>
            <?php
                EventoController::armaCatalogo($grupo6, $evento->id, 6,4);
            ?>
        <?php endif; ?>
        <?php if(!empty($grupo7)): ?>
            <h5 class="text-primary">Grupo VII</h5>
            <?php
                EventoController::armaCatalogo($grupo7, $evento->id, 7,4);
            ?>
        <?php endif; ?>
        <?php if(!empty($grupo8)): ?>
            <h5 class="text-primary">Grupo VIII</h5>
            <?php
                EventoController::armaCatalogo($grupo8, $evento->id, 8,4);
            ?>
        <?php endif; ?>
        <?php if(!empty($grupo9)): ?>
            <h5 class="text-primary">Grupo IX</h5>
            <?php
                EventoController::armaCatalogo($grupo9, $evento->id, 9,4);
            ?>
        <?php endif; ?>
        <?php if(!empty($grupo10)): ?>
            <h5 class="text-primary">Grupo X</h5>
            <?php
                EventoController::armaCatalogo($grupo10, $evento->id, 10,4);
            ?>
        <?php endif; ?>
        <?php if(!empty($grupo11)): ?>
            <h5 class="text-primary">Grupo XI</h5>
            <?php
                EventoController::armaCatalogo($grupo11, $evento->id, 11,4);
            ?>
        <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script src="<?php echo e(asset('assets/js/pages/crud/forms/widgets/bootstrap-switch.js')); ?>"></script>
    <script type="text/javascript">
        $.ajaxSetup({
            // definimos cabecera donde estarra el token y poder hacer nuestras operaciones de put,post...
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/evento/catalogo.blade.php ENDPATH**/ ?>