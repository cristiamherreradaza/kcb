<link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<table class="table table-bordered table-hover table-striped" id="tabla_criaderos">
    <thead>
        <tr>
            <th>ID</th>
            <th>KCB</th>
            <th>NOMBRE</th>
            <th>CHIP</th>
            <th>RAZA</th>
            <th>PROPIETARIO</th>
            <th>DEPARTAMENTO</th>
            
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($e->id); ?></td>
            <td><?php echo e($e->kcb); ?></td>
            <td><?php echo e($e->nombre_completo); ?></td>
            <td><?php echo e($e->chip); ?></td>
            <td>
                <?php if($e->raza_id != null): ?>
                    <?php echo e($e->raza['nombre']); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($e->propietario_id != null): ?>
                    <?php echo e($e->propietario['name']); ?>

                <?php endif; ?>
            </td>
            <td><?php echo e($e->departamento); ?></td>
            <td style="width: 10%">
                <button type="button" class="btn btn-icon btn-warning" onclick="edita('<?php echo e($e->id); ?>')">
                    <i class="flaticon2-edit"></i>
                </button>
                <?php if($e->camada_id != null): ?>
                    <button type="button" class="btn btn-icon btn-dark" onclick="camada('<?php echo e($e->camada_id); ?>')">
                        <i class="fab fa-buromobelexperte"></i>
                    </button>
                <?php endif; ?>
                <button type="button" class="btn btn-icon btn-info" onclick="informacion('<?php echo e($e->id); ?>')">
                    <i class="far fa-file-alt"></i>
                </button>
                <button type="button" class="btn btn-icon btn-primary" onclick="logs('<?php echo e($e->id); ?>')">
                    <i class="far fa-keyboard"></i>
                </button>
                <?php
                    $padre = App\Camada::where('padre_id',$e->id)->count();
                    $madre = App\Camada::where('madre_id',$e->id)->count();
                    if($padre>0 || $madre>0){
                        $table = 0;
                        if($padre>0){
                            $table = 1;
                        }
                        echo '<button type="button" class="btn btn-icon btn-success" onclick="PadresCamadas('.$e->id.','.$table.')">
                                <i class="fas fa-bezier-curve"></i>
                            </button>';
                    }
                    // elseif($madre>0){
                    //     echo '<button type="button" class="btn btn-icon btn-success" onclick="">
                    //             <i class="fas fa-bezier-curve"></i>
                    //         </button>';
                    // }
                ?>

                <button type="button" class="btn btn-icon btn-danger" onclick="elimina('<?php echo e($e->id); ?>', '<?php echo e($e->nombre); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="text-danger">NO EXISTEN DATOS</h3>
        <?php endif; ?>
    </tbody>
    <tbody>
    </tbody>
</table>
<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<script>
    $('#tabla_criaderos').DataTable({
        order: [[ 0, "desc" ]],
        searching: false,
        lengthChange: false,
        responsive: true,
        language: {
            url: '<?php echo e(asset('datatableEs.json')); ?>'
        },
    });
</script>
<?php /**PATH C:\laragon\www\kcb\resources\views/ejemplar/ajaxListado.blade.php ENDPATH**/ ?>