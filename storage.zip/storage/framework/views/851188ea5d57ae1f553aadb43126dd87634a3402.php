

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<!--begin::Card-->
	<div class="card card-custom gutter-b">
		<div class="card-header flex-wrap py-3">
			<div class="card-title">
				<h3 class="card-label">CALIFICACION
				</h3>
			</div>
			<div class="card-toolbar">
				<!--begin::Button-->
				
				<!--end::Button-->
			</div>
		</div>

		<div class="card-body">
            <?php
                $contador = 0 ;

                $colores = array("success", "warning", "info", "dark", "danger", "primary");

            ?>
            <?php while($contador < $cantidadAsignaciones): ?>
                <div class="row">
                    <?php for($i = 0; $i < 3; $i++): ?>
                        <?php
                            $seleccion = array_rand($colores);
                        ?>
                        <?php if($contador < $cantidadAsignaciones): ?>
                            <div class="col-md-4">
                                <div class="card card-custom wave wave-animate-slow wave-<?php echo e($colores[$seleccion]); ?> mb-8 mb-lg-0">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center p-5">
                                            <div class="mr-6">
                                                <i class="fa fa-dog fa-5x text-<?php echo e($colores[$seleccion]); ?>"></i>
                                            </div>
                                            <div class="d-flex flex-column">
                                                
                                                <a href="<?php echo e(url('Juez/categorias', [$asignaciones[$contador]->evento_id, $asignaciones[$contador]->id])); ?>" class="btn btn-success btn-block"> <i class="fa fa-check"></i> Calificar</a>
                                                
                                                <div class="text-dark-100"><h4><?php echo e($asignaciones[$contador]->evento->nombre); ?></h4></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                $contador++;
                            ?>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <br>
            <?php endwhile; ?>
		</div>
	</div>
	<!--end::Card-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
    <script type="text/javascript">

    	$(function () {
    	    $('#tabla-insumos').DataTable({
				responsive: true,
    	        language: {
    	            url: '<?php echo e(asset('datatableEs.json')); ?>',
    	        },
				order: [[ 0, "desc" ]]
    	    });

    	});

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/juez/calificacion.blade.php ENDPATH**/ ?>