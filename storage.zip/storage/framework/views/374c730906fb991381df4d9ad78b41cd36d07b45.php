<table class="table table-striped">
    <thead>
        <tr>
            <th>KCB</th>
            <th>NOMBRE</th>
            <th>RAZA</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($e->kcb); ?></td>
                <td><?php echo e($e->nombre_completo); ?></td>
                <td>                   
                    <?php if($e->raza_id != null): ?>
                    <?php echo e($e->raza->nombre); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <a href="#" class="btn btn-icon btn-success" onclick="selecciona(`<?php echo e($e->id); ?>`, '<?php echo e($e->kcb); ?>', `<?php echo e(trim($e->nombre_completo)); ?>` ,`<?php echo e($e->sexo); ?>`, `<?php echo e($camada); ?>`);">
                        <i class="fas fa-check"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2 class="text-danger">NO EXISTEN REGISTROS</h2>
        <?php endif; ?>
    </tbody>
</table>
<script type="text/javascript">
    function selecciona(id, kcb, nombre_completo, sexo, camada)
    {
        if(camada) {
            //console.log(camada);
            let camda_id = $('#add_camada_id').val();
            window.location.href = "<?php echo e(url('Ejemplar/guardaEjemplarCamada')); ?>/"+camda_id+"/"+id;         
        }else{
            if(sexo == 'Macho'){
                var boton = '<button type="button" class="btn btn-sm btn-primary btn-block" onclick="seleccionaPadre()">'+'KCB: '+kcb+' NOMBRE: '+nombre_completo+'</button>';
                $("#btn-padre").html(boton);
                $("#modal-padres").modal('hide');
                $("#padre_id").val(id);
            }else{
                var boton = '<button type="button" class="btn btn-sm btn-info btn-block" onclick="seleccionaMadre()">'+'KCB: '+kcb+' NOMBRE: '+nombre_completo+'</button>';
                $("#btn-madre").html(boton);
                $("#modal-padres").modal('hide');
                $("#madre_id").val(id);
            }
        }
    }
</script><?php /**PATH C:\laragon\www\kcb\resources\views/ejemplar/ajaxBuscaEjemplar.blade.php ENDPATH**/ ?>