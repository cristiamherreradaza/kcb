<link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<table class="table table-bordered table-hover table-striped" id="tabla_usuarios">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Celular</th>
            <th>Cedula</th>
            <th>Departamento</th>
            <th>Tipo</th>
            <th>Camada</th>
            <th>Criaderos</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $datosPropietarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->id); ?></td>
            <td><?php echo e($p->name); ?></td>
            <td><?php echo e($p->email); ?></td>
            <td><?php echo e($p->celulares); ?></td>
            <td><?php echo e($p->ci); ?></td>
            <td><?php echo e($p->departamento); ?></td>
            <td><?php echo e($p->tipo); ?></td>
            <td>
                <?php
                    $ejemplar = App\Ejemplar::where('propietario_id',$p->id)
                                            ->orderBy('id','desc')
                                            ->first();
                    if($ejemplar){
                        if($ejemplar->camada){
                            echo $ejemplar->camada->camada;
                        }
                    }
                ?>
            </td>
            <td>
                <?php
                    $cantidad = App\PropietarioCriadero::where('propietario_id', $p->id)
                                                        ->count();

                    echo $cantidad;
                ?>
            </td>
            <td>
                <button type="button" class="btn btn-sm btn-icon btn-warning" onclick="edita('<?php echo e($p->id); ?>')">
                    <i class="flaticon2-edit"></i>
                </button>
                <button type="button" class="btn btn-sm btn-icon btn-success" onclick="listaCriadero('<?php echo e($p->id); ?>')">
                    <i class="fas fa-dog"></i>
                </button>
                <button type="button" class="btn btn-sm btn-icon btn-danger"
                    onclick="elimina('<?php echo e($p->id); ?>', '<?php echo e($p->name); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="text-danger">NO EXISTEN USUARIOS</h3>
        <?php endif; ?>
    </tbody>
    <tbody>
    </tbody>
</table>
<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<script>
    $('#tabla_usuarios').DataTable({
        order: [[ 0, "desc" ]],
        searching: false,
        lengthChange: false,
        responsive: true,
        language: {
            url: '<?php echo e(asset('datatableEs.json')); ?>'
        },
    });
</script><?php /**PATH C:\laragon\www\kcb\resources\views/user/ajaxListadoPropietarios.blade.php ENDPATH**/ ?>