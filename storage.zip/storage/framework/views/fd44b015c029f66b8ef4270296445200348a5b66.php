<?php if( $ejemplar->sexo == "Macho"): ?>
    <button type="button" class="btn btn-block btn-primary" onclick="edicionAjaxBuscaEjemplar('Macho')">Nombre: <?php echo e($ejemplar->nombre); ?></button>
<?php else: ?>
    <button type="button" class="btn btn-block btn-info" onclick="edicionAjaxBuscaEjemplar('Hembra')">Nombre: <?php echo e($ejemplar->nombre); ?></button>
<?php endif; ?>

<script type="text/javascript">
    if('<?php echo e($ejemplar->sexo); ?>' == "Macho"){
        $("#edicion_padre_id").val(<?php echo e($ejemplar->id); ?>);
    }else{
        $("#edicion_madre_id").val(<?php echo e($ejemplar->id); ?>);
    }
    // $("#edicion_ejemplar_id_editar").val(<?php echo e($ejemplar->id); ?>);
</script><?php /**PATH C:\laragon\www\kcb\resources\views/ejemplar/ajaxGuardaEjemplar.blade.php ENDPATH**/ ?>