<table class="table table-striped">
    <thead>
        <tr>
            <th>FECHA</th>
            <th>PROPIETARIO</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ejemplarTransferencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $et): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($et->fecha_transferencia); ?></td>
            <td><?php echo e($et->propietario->name); ?></td>
            <td>
                <button type="button" class="btn btn-sm btn-icon btn-danger" onclick="eliminaTransferencia('<?php echo e($et->id); ?>', '<?php echo e($et->propietario->name); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>No tiene Transferencias</h3>
        <?php endif; ?>
    </tbody>
</table>    
<a href="#" class="btn btn-info btn-block" onclick="nuevaTransferencia()">Nueva Tramsferencia</a><?php /**PATH C:\laragon\www\kcb\resources\views/ejemplar/ajaxGuardaTransferencia.blade.php ENDPATH**/ ?>