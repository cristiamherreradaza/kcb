<div class="aside-menu-wrapper flex-column-fluid" id="kt_aside_menu_wrapper">
	<!--begin::Menu Container-->
	<div id="kt_aside_menu" class="aside-menu my-4" data-menu-vertical="1" data-menu-scroll="1" data-menu-dropdown-timeout="500">
		<!--begin::Menu Nav-->
		<ul class="menu-nav">

			<li>
				<div class="text-center mb-10">
					<div class="symbol symbol-60 symbol-circle">
						
							<div class="symbol-label" style="background-image:url('<?php echo e(url('assets/media/logo.png')); ?>')">
						</div>
						<i class="symbol-badge symbol-badge-bottom bg-success"></i>
					</div>
					<?php if(auth()->guard()->check()): ?>
					<h4 class="font-weight-bold my-2 text-success"><?php echo e(Auth::user()->name); ?></h4>
					<div class="text-light mb-2"><?php echo e(Auth::user()->perfil->nombre); ?></div>

					<br />
					<a href="<?php echo e(route('logout')); ?>"
						onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
						class="label label-light-danger label-inline font-weight-bold label-lg">Salir</a>
					<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
						<?php echo csrf_field(); ?>
					</form>
					<?php endif; ?>
				</div>
			</li> 
			
			<li class="menu-section">
				<h4 class="menu-text">MENU ADMINISTRACION</h4>
				<i class="menu-icon ki ki-bold-more-hor icon-md"></i>
			</li>
			<?php
				$estado = "Visible";
				$user_id = Auth::user()->id;
				$menus = App\MenuUsers::where('user_id',$user_id)
										->where('estado',$estado)	
										->get();
			?>
			<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
				<?php if($m->menu): ?>
					<?php if($m->menu->direccion == '#' && $m->estado == 'Visible'): ?>
						<a href="javascript:;" class="menu-link menu-toggle">
							<span class="menu-icon"><i class="<?php echo e($m->menu->icono); ?>"></i></span>
							<span class="menu-text"><?php echo e($m->menu->nombre); ?></span>
							<i class="menu-arrow"></i>
						</a>
						<?php
							$menuPadre = $m->menu_id;
							$menusHijos = App\Menu::where('padre',$menuPadre)->get();
						?>
						<div class="menu-submenu">
							<i class="menu-arrow"></i>
							<ul class="menu-subnav">
								<li class="menu-item menu-item-parent" aria-haspopup="true">
									<span class="menu-link">
										<span class="menu-text"><?php echo e($m->menu->nombre); ?></span>
									</span>
								</li>
								<?php $__currentLoopData = $menusHijos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php
										$estado = App\menuUsers::where('user_id',$user_id)
															->where('menu_id',$mh->id)
															->first();
									?>
									<?php if($estado): ?>
										<?php if($estado->estado == "Visible"): ?>
											<li class="menu-item" aria-haspopup="true">
												<a href="<?php echo e(url($mh->direccion)); ?>" class="menu-link">
													<i class="menu-bullet menu-bullet-dot">
														<span></span>
													</i>
													<span class="menu-text"><?php echo e($mh->nombre); ?></span>
												</a>
											</li>	
										<?php endif; ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<li class="menu-item menu-item-submenu" aria-haspopup="true" data-menu-toggle="hover">
				<a href="javascript:;" class="menu-link menu-toggle">
					<span class="menu-icon"><i class="fas fa-check"></i></span>
					<span class="menu-text">Calificacion</span>
					<i class="menu-arrow"></i>
				</a>
				<div class="menu-submenu">
					<i class="menu-arrow"></i>
					<ul class="menu-subnav">
						<li class="menu-item menu-item-parent" aria-haspopup="true">
							<span class="menu-link">
								<span class="menu-text">Calificacion</span>
							</span>
						</li>

						<li class="menu-item" aria-haspopup="true">
							<a href="<?php echo e(url('Juez/calificacion')); ?>" class="menu-link">
								<i class="menu-bullet menu-bullet-dot">
									<span></span>
								</i>
								<span class="menu-text">Listado Eventos</span>
							</a>
						</li>

						
					</ul>
				</div>
			</li>
			<li class="menu-section bg-success-o-100 p-10">
				<h4 class="menu-text text-center text-white">Kennel Club Boliviano administrador Club Canofilo de Bolivia S.R.L.</h4>
				<i class="menu-icon ki ki-bold-more-hor icon-md"></i>
			</li>

			

			
		
			

			
		</ul>
		<!--end::Menu Nav-->
	</div>
	<!--end::Menu Container-->
</div><?php /**PATH C:\laragon\www\kcb\resources\views/partials/menu.blade.php ENDPATH**/ ?>