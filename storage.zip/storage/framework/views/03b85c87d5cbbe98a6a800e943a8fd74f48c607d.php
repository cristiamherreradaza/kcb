<table class="table table-striped">
    <thead>
        <tr>
            <th>CEDULA</th>
            <th>NOMBRE</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $propietarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($pro->ci); ?></td>
                <td><?php echo e($pro->name); ?></td>
                <td>
                    <a href="#" class="btn btn-icon btn-success" onclick="selecciona(`<?php echo e($pro->id); ?>`, `<?php echo e(trim($pro->name)); ?>` ,`<?php echo e($pro->ci); ?>`);">
                        <i class="fas fa-check"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h2 class="text-danger">NO EXISTEN REGISTROS</h2>
        <?php endif; ?>
    </tbody>
</table>
<script type="text/javascript">
    function selecciona(id, nombre_completo, cedula){

        var boton = '<button class="btn btn-primary btn-block" type="button" onclick="BuscaPropietario()">Cedula: '+cedula+' Nombre:  '+nombre_completo+'</button>'
        $('#transferencia_propietario').html(boton);
        $('#modal-propietario').modal('hide');
        $('#transferencia_propietario_id').val(id);
        $('#modal-tramsferencia').modal('show');
    }
</script><?php /**PATH C:\laragon\www\kcb\resources\views/user/ajaxBuscaPropietario.blade.php ENDPATH**/ ?>