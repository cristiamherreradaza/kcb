

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
    <style>
        .especiales{
            font-size:60px;
            position: absolute;
            color: rgb(0, 8, 245);
            font-weight: bold;
            -webkit-text-stroke: 2px rgb(255, 255, 255);
        }
        #primeroEspecial{
            margin-left:280px;
            margin-top:50px;
        }
        #segundoEspecial{
            margin-left:160px;
            margin-top:60px;
        }
        #terceroEspecial{
            margin-left:395px;
            margin-top:70px;
        }
        #cuartoEspecial{
            margin-left:25px;
            margin-top:80px;
        }
        #quintooEspecial{
            margin-left:515px;
            margin-top:85px;
        }
        
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('metadatos'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<!--begin::Card-->
	<div class="card card-custom gutter-b">
		<div class="card-header flex-wrap py-3">
			<div class="card-title">
				<h3 class="card-label">KANKING GANADORES</h3>
			</div>
		</div>
		<div class="card-body">
            
            <div class="card-header card-header-tabs-line">
                <div class="card-toolbar">
                    <ul class="nav nav-tabs nav-tabs-space-lg nav-tabs-line nav-bold nav-tabs-line-3x" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="tab" href="#kt_apps_contacts_view_tab_1">
                                <span class="nav-icon mr-2">
                                    <span class="svg-icon mr-3">
                                        <!--begin::Svg Icon | path:/metronic/theme/html/demo1/dist/assets/media/svg/icons/General/Notification2.svg-->
                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <rect x="0" y="0" width="24" height="24" />
                                                <path d="M13.2070325,4 C13.0721672,4.47683179 13,4.97998812 13,5.5 C13,8.53756612 15.4624339,11 18.5,11 C19.0200119,11 19.5231682,10.9278328 20,10.7929675 L20,17 C20,18.6568542 18.6568542,20 17,20 L7,20 C5.34314575,20 4,18.6568542 4,17 L4,7 C4,5.34314575 5.34314575,4 7,4 L13.2070325,4 Z" fill="#000000" />
                                                <circle fill="#000000" opacity="0.3" cx="18.5" cy="5.5" r="2.5" />
                                            </g>
                                        </svg>
                                        <!--end::Svg Icon-->
                                    </span>
                                </span>
                                <span class="nav-text">MEJORES DE RAZAS</span>
                            </a>
                        </li>
                        <li class="nav-item mr-3">
                            <a class="nav-link" data-toggle="tab" href="#kt_apps_contacts_view_tab_2">
                                <span class="nav-icon mr-2">
                                    <span class="svg-icon mr-3">
                                        <!--begin::Svg Icon | path:/metronic/theme/html/demo1/dist/assets/media/svg/icons/Communication/Chat-check.svg-->
                                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <rect x="0" y="0" width="24" height="24" />
                                                <path d="M4.875,20.75 C4.63541667,20.75 4.39583333,20.6541667 4.20416667,20.4625 L2.2875,18.5458333 C1.90416667,18.1625 1.90416667,17.5875 2.2875,17.2041667 C2.67083333,16.8208333 3.29375,16.8208333 3.62916667,17.2041667 L4.875,18.45 L8.0375,15.2875 C8.42083333,14.9041667 8.99583333,14.9041667 9.37916667,15.2875 C9.7625,15.6708333 9.7625,16.2458333 9.37916667,16.6291667 L5.54583333,20.4625 C5.35416667,20.6541667 5.11458333,20.75 4.875,20.75 Z" fill="#000000" fill-rule="nonzero" opacity="0.3" />
                                                <path d="M2,11.8650466 L2,6 C2,4.34314575 3.34314575,3 5,3 L19,3 C20.6568542,3 22,4.34314575 22,6 L22,15 C22,15.0032706 21.9999948,15.0065399 21.9999843,15.009808 L22.0249378,15 L22.0249378,19.5857864 C22.0249378,20.1380712 21.5772226,20.5857864 21.0249378,20.5857864 C20.7597213,20.5857864 20.5053674,20.4804296 20.317831,20.2928932 L18.0249378,18 L12.9835977,18 C12.7263047,14.0909841 9.47412135,11 5.5,11 C4.23590829,11 3.04485894,11.3127315 2,11.8650466 Z M6,7 C5.44771525,7 5,7.44771525 5,8 C5,8.55228475 5.44771525,9 6,9 L15,9 C15.5522847,9 16,8.55228475 16,8 C16,7.44771525 15.5522847,7 15,7 L6,7 Z" fill="#000000" />
                                            </g>
                                        </svg>
                                        <!--end::Svg Icon-->
                                    </span>
                                </span>
                                <span class="nav-text">PODIO</span>
                            </a>
                        </li>
                        <li class="nav-item mr-3">
                            <a class="nav-link" data-toggle="tab" href="#kt_apps_contacts_view_tab_3">
                                <span class="nav-icon mr-2">
                                    <span class="svg-icon mr-3">
                                        <i class="fa fa-users"></i>
                                    </span>
                                </span>
                                <span class="nav-text">GRUPOS</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!--end::Header-->
            <!--begin::Body-->
            <div class="card-body px-0">
                <div class="tab-content pt-5">
                    <!--begin::Tab Content-->
                    <div class="tab-pane active" id="kt_apps_contacts_view_tab_1" role="tabpanel">
                        <div class="container">
                            <?php
                                $contadoresRazas = 0;
                                $cantidadRazas = count($ejemplares);
                            ?>
                            <?php while($contadoresRazas < $cantidadRazas): ?>
                                <div class="row">
                                    <?php for($i = 1 ; $i <= 4 ; $i++): ?>
                                        <?php if($contadoresRazas < $cantidadRazas): ?>
                                            <div class="col-xl-3 border">
                                                <!--begin::Card-->
                                                <div class="card card-custom gutter-b card-stretch" id="bloque_raza_<?php echo e($ejemplares[$contadoresRazas]['raza_id']); ?>">
                                                    <!--begin::Body-->
                                                    <div class="card-body pt-4 d-flex flex-column justify-content-between">
                                                        <!--begin::User-->
                                                        <div class="">
                                                            <center>
                                                                <!--begin::Title-->
                                                                <div class="d-flex flex-column">
                                                                    <a id="download_<?php echo e($ejemplares[$contadoresRazas]['raza_id']); ?>" onclick="sacarCaptura('<?php echo e($ejemplares[$contadoresRazas]['raza_id']); ?>')">
                                                                        <h4 style="height: 50px;" class="text-success font-weight-bold text-hover-primary mb-0"><?php echo e(str_replace(['(', ')', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'], '' , $ejemplares[$contadoresRazas]['nombre'])); ?></h4>
                                                                    </a>
                                                                </div>
                                                                <!--end::Title-->
                                                            </center>
                                                        </div>
                                                        <!--end::User-->
                                                        <!--begin::Desc-->
                                                        <?php if($ejemplares[$contadoresRazas]['mejorCachoro'] || $ejemplares[$contadoresRazas]['mejorCachoroSexoOpuesto']): ?>
                                                            <p class="text-center text-info">
                                                                Cachorro
                                                            </p>
                                                            <div class="row text-center">
                                                                <div class="col-md-6">
                                                                    <?php if($ejemplares[$contadoresRazas]['mejorCachoro']): ?>
                                                                        <span class="text-primary">MEJOR CACHORRO</span>
                                                                        <br>
                                                                        <h5><?php echo e($ejemplares[$contadoresRazas]['mejorCachoro']->numero_prefijo); ?></h5>

                                                                        <img class="listonMejor" src="<?php echo e(url('img/liston2.png')); ?>" alt="" width="35%">

                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <?php if($ejemplares[$contadoresRazas]['mejorCachoroSexoOpuesto']): ?>
                                                                        <span class="text-primary">MEJOR SEXO OPUESTO</span>
                                                                        <br>
                                                                        <h5><?php echo e($ejemplares[$contadoresRazas]['mejorCachoroSexoOpuesto']->numero_prefijo); ?></h5>

                                                                        <img class="listonMejor" src="<?php echo e(url('img/liston2.png')); ?>" alt="" width="35%">

                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if($ejemplares[$contadoresRazas]['mejorJoven'] || $ejemplares[$contadoresRazas]['mejorJovenSexoOpuesto']): ?>
                                                            <p class="text-center text-info">
                                                                Joven
                                                            </p>
                                                            <div class="row text-center">
                                                                <div class="col-md-6">
                                                                    <?php if($ejemplares[$contadoresRazas]['mejorJoven']): ?>
                                                                        <span class="text-primary">MEJOR JOVEN</span>
                                                                        <br>
                                                                        <h5><?php echo e($ejemplares[$contadoresRazas]['mejorJoven']->numero_prefijo); ?></h5>

                                                                        <img class="listonMejor" src="<?php echo e(url('img/liston.png')); ?>" alt="" width="40%">

                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <?php if($ejemplares[$contadoresRazas]['mejorJovenSexoOpuesto']): ?>
                                                                        <span class="text-primary">MEJOR SEXO OPUESTO</span>
                                                                        <br>
                                                                        <h5><?php echo e($ejemplares[$contadoresRazas]['mejorJovenSexoOpuesto']->numero_prefijo); ?></h5>

                                                                        <img class="listonMejor" src="<?php echo e(url('img/liston.png')); ?>" alt="" width="40%">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <?php if($ejemplares[$contadoresRazas]['mejorRaza'] || $ejemplares[$contadoresRazas]['mejorRazaSexoOpuesto']): ?>
                                                            <p class="text-center text-info">
                                                                Raza
                                                            </p>
                                                            <div class="row text-center">
                                                                <div class="col-md-6">
                                                                    <?php if($ejemplares[$contadoresRazas]['mejorRaza']): ?>
                                                                        <span class="text-primary">MEJOR DE LA RAZA</span>
                                                                        <br>
                                                                        <h5><?php echo e($ejemplares[$contadoresRazas]['mejorRaza']->numero_prefijo); ?></h5>
                                                                        <?php if($ejemplares[$contadoresRazas]['mejorRaza']->certificacionCLACAB == "Si"): ?>
                                                                            <i class="fa fa-star text-primary" aria-hidden="true"></i>  
                                                                        <?php endif; ?>
                                                                        <?php if($ejemplares[$contadoresRazas]['mejorRaza']->certificacionCACIB == "Si"): ?>
                                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>  
                                                                        <?php endif; ?>

                                                                        <img class="listonMejor" src="<?php echo e(url('img/liston1.png')); ?>" alt="" width="35%">

                                                                    <?php endif; ?>
                                                                </div>
                                                                
                                                                <div class="col-md-6">
                                                                    <?php if($ejemplares[$contadoresRazas]['mejorRazaSexoOpuesto']): ?>
                                                                        <span class="text-primary">MEJOR SEXO OPUESTO</span>
                                                                        <br>
                                                                        <h5><?php echo e($ejemplares[$contadoresRazas]['mejorRazaSexoOpuesto']->numero_prefijo); ?></h5>
                                                                        <?php if($ejemplares[$contadoresRazas]['mejorRazaSexoOpuesto']->certificacionCLACAB == "Si"): ?>
                                                                            <i class="fa fa-star text-primary" aria-hidden="true"></i>  
                                                                        <?php endif; ?>
                                                                        <?php if($ejemplares[$contadoresRazas]['mejorRazaSexoOpuesto']->certificacionCACIB == "Si"): ?>
                                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>  
                                                                        <?php endif; ?>

                                                                        <img class="listonMejor" src="<?php echo e(url('img/liston1.png')); ?>" alt="" width="35%">

                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        <?php endif; ?>
                                                        <!--end::Desc-->
                                                    </div>
                                                    <!--end::Body-->
                                                </div>
                                                <!--end::Card-->
                                            </div>
                                        <?php endif; ?>
                                            
                                        <?php
                                            $contadoresRazas++;
                                        ?>
                                    <?php endfor; ?>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    <!--end::Tab Content-->
                    <!--begin::Tab Content-->
                    <div class="tab-pane" id="kt_apps_contacts_view_tab_2" role="tabpanel">

                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-block btn-success" onclick="sacarCapturaPodio()">Sacar captura</button>
                            </div>
                        </div>

                        <hr>

                        <div class="container bg-white" id="contenedor_final_podio">
                            <div class="row text-center">
                                <div class="col-md-6" style="background-image: url(<?php echo e(url('img/podioKennel2.jpg')); ?>); background-size: 100%; background-repeat: no-repeat;">
                                    <h1 class="text-dark text-bold bg-white">CACHORROS ESPECIALES</h1>
                                    <p id="primeroEspecial" class="especiales">
                                        <?php if($arrarEspeciales['primero']): ?>
                                            <?php echo e($arrarEspeciales['primero']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="segundoEspecial" class="especiales">
                                        <?php if($arrarEspeciales['segundo']): ?>
                                            <?php echo e($arrarEspeciales['segundo']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="terceroEspecial" class="especiales">
                                        <?php if($arrarEspeciales['tercer']): ?>
                                            <?php echo e($arrarEspeciales['tercer']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="cuartoEspecial" class="especiales">
                                        <?php if($arrarEspeciales['cuarto']): ?>
                                            <?php echo e($arrarEspeciales['cuarto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="quintooEspecial" class="especiales">
                                        <?php if($arrarEspeciales['quinto']): ?>
                                            <?php echo e($arrarEspeciales['quinto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <div style="height: 250px;"></div>
                                </div>
                                <div class="col-md-6" style="background-image: url(<?php echo e(url('img/podioKennel2.jpg')); ?>); background-size: 100%; background-repeat: no-repeat;">
                                    <h1 class="text-dark text-bold bg-white">CACHORROS ABSOLUTOS</h1>
                                    <p id="primeroEspecial" class="especiales">
                                        <?php if($arrarAbsoluto['primero']): ?>
                                            <?php echo e($arrarAbsoluto['primero']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="segundoEspecial" class="especiales">
                                        <?php if($arrarAbsoluto['segundo']): ?>
                                            <?php echo e($arrarAbsoluto['segundo']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="terceroEspecial" class="especiales">
                                        <?php if($arrarAbsoluto['tercer']): ?>
                                            <?php echo e($arrarAbsoluto['tercer']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="cuartoEspecial" class="especiales">
                                        <?php if($arrarAbsoluto['cuarto']): ?>
                                            <?php echo e($arrarAbsoluto['cuarto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="quintooEspecial" class="especiales">
                                        <?php if($arrarAbsoluto['quinto']): ?>
                                            <?php echo e($arrarAbsoluto['quinto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    
                                </div>
                            </div>
                            <br>
                            <div class="row text-center">
                                <div class="col-md-6" style="background-image: url(<?php echo e(url('img/podioKennel2.jpg')); ?>); background-size: 100%; background-repeat: no-repeat;">
                                    <h1 class="text-dark text-bold bg-white">JOVENES</h1>
                                    <p id="primeroEspecial" class="especiales">
                                        <?php if($arrarJoven['primero']): ?>
                                            <?php echo e($arrarJoven['primero']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="segundoEspecial" class="especiales">
                                        <?php if($arrarJoven['segundo']): ?>
                                            <?php echo e($arrarJoven['segundo']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="terceroEspecial" class="especiales">
                                        <?php if($arrarJoven['tercer']): ?>
                                            <?php echo e($arrarJoven['tercer']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="cuartoEspecial" class="especiales">
                                        <?php if($arrarJoven['cuarto']): ?>
                                            <?php echo e($arrarJoven['cuarto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="quintooEspecial" class="especiales">
                                        <?php if($arrarJoven['quinto']): ?>
                                            <?php echo e($arrarJoven['quinto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <div style="height: 250px;"></div>
                                    
                                </div>
                                <div class="col-md-6" style="background-image: url(<?php echo e(url('img/podioKennel2.jpg')); ?>); background-size: 100%; background-repeat: no-repeat;">
                                    <h1 class="text-dark text-bold bg-white">ADULTOS</h1>
                                    <p id="primeroEspecial" class="especiales">
                                        <?php if($arrarAdulto['primero']): ?>
                                            <?php echo e($arrarAdulto['primero']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="segundoEspecial" class="especiales">
                                        <?php if($arrarAdulto['segundo']): ?>
                                            <?php echo e($arrarAdulto['segundo']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="terceroEspecial" class="especiales">
                                        <?php if($arrarAdulto['tercer']): ?>
                                            <?php echo e($arrarAdulto['tercer']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="cuartoEspecial" class="especiales">
                                        <?php if($arrarAdulto['cuarto']): ?>
                                            <?php echo e($arrarAdulto['cuarto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p id="quintooEspecial" class="especiales">
                                        <?php if($arrarAdulto['quinto']): ?>
                                            <?php echo e($arrarAdulto['quinto']->numero_prefijo); ?>

                                        <?php endif; ?>
                                    </p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--end::Tab Content-->
                    <!--begin::Tab Content-->
                    <div class="tab-pane" id="kt_apps_contacts_view_tab_3" role="tabpanel">
                        <div class="container">
                            <div class="row text-center">
                                <div class="col-md-6 bg-white" id="grupo_1">
                                    <a onclick="sacarCapturaGrupos(1)">
                                        <h1>CACHORROS ESPECIALES</h1>
                                    </a>
                                    <table class="table table-bordered table-hover table-striped" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <?php $__currentLoopData = $array_grupoEspeciales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th>GRUPO <?php echo e($ag[0]['grupo_id']); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php for($i = 0; $i < $mayorEspecial; $i++): ?>
                                                <tr>
                                                    <?php $__currentLoopData = $array_grupoEspeciales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(count($ag) > $i): ?>
                                                            <td>
                                                                <?php echo e($ag[$i]->numero_prefijo); ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td></td>                        
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-6 bg-white" id="grupo_2">
                                    <a onclick="sacarCapturaGrupos(2)">
                                        <h1>CACHORROS ABSOLUTOS</h1>
                                    </a>
                                    <table class="table table-bordered table-hover table-striped" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <?php $__currentLoopData = $array_grupoAbsoluto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th>GRUPO <?php echo e($ag[0]['grupo_id']); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php for($i = 0; $i < $mayorAbsoluto; $i++): ?>
                                                <tr>
                                                    <?php $__currentLoopData = $array_grupoAbsoluto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(count($ag) > $i): ?>
                                                            <td>
                                                                <?php echo e($ag[$i]->numero_prefijo); ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td></td>                        
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <br>
                            <div class="row text-center">
                                <div class="col-md-6 bg-white" id="grupo_3">
                                    <a onclick="sacarCapturaGrupos(3)">
                                        <h1>JOVENES</h1>
                                    </a>
                                    <table class="table table-bordered table-hover table-striped" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <?php $__currentLoopData = $array_grupoJovenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th>GRUPO <?php echo e($ag[0]['grupo_id']); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php for($i = 0; $i < $mayorJovenes; $i++): ?>
                                                <tr>
                                                    <?php $__currentLoopData = $array_grupoJovenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(count($ag) > $i): ?>
                                                            <td>
                                                                <?php echo e($ag[$i]->numero_prefijo); ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td></td>                        
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-6 bg-white" id="grupo_4">
                                    <a onclick="sacarCapturaGrupos(4)">
                                        <h1>ADULTOS</h1>
                                    </a>
                                    <table class="table table-bordered table-hover table-striped" style="width:100%;">
                                        <thead>
                                            <tr>
                                                <?php $__currentLoopData = $array_grupoAdultos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th>GRUPO <?php echo e($ag[0]['grupo_id']); ?></th>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php for($i = 0; $i < $mayorAdultos; $i++): ?>
                                                <tr>
                                                    <?php $__currentLoopData = $array_grupoAdultos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(count($ag) > $i): ?>
                                                            <td>
                                                                <?php echo e($ag[$i]->numero_prefijo); ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td></td>                        
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--end::Tab Content-->
                </div>
            </div>
            <!--end::Body-->
        </div>
	</div>
	<!--end::Card-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
    <script src="https://superal.github.io/canvas2image/canvas2image.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>

    <script type="text/javascript">

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

        function sacarCaptura(raza){
            html2canvas(document.querySelector("#bloque_raza_"+raza), {
                onrendered: function(canvas) {
                    return Canvas2Image.saveAsPNG(canvas,4128,2500);
                }
            });
        }

        function sacarCapturaPodio(){
            html2canvas(document.querySelector("#contenedor_final_podio"), {
                onrendered: function(canvas1) {
                    // return Canvas2Image.saveAsPNG(canvas,4128,2500);
                    return Canvas2Image.saveAsJPEG(canvas1,4128,2500);
                    // return Canvas2Image.convertToJPEG(canvas1,4128,2500);
                }
            });
        }

        function sacarCapturaGrupos(grupo){
            html2canvas(document.querySelector("#grupo_"+grupo), {
                onrendered: function(canvas1) {
                    // return Canvas2Image.saveAsPNG(canvas,4128,2500);
                    return Canvas2Image.saveAsJPEG(canvas1,4128,2500);
                    // return Canvas2Image.convertToJPEG(canvas1,4128,2500);
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/evento/ranking.blade.php ENDPATH**/ ?>