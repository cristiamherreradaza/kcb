<hr>
<h4 class="text-center text-warning" id="cantidad_de_asignacion">
    <?php
        if($faltantes == 0){
            echo 'YA ASIGNO LA CANTIDAD TOPE JUEZ POR PISTA';
        }else{
            echo "AUN FALTAN ".$faltantes." ASIGNACIONES";
        }
    ?>
</h4>
<hr>
<h2 class="text-success text-center">Asignacion</h2>
<hr>
<table class="table table-striped">
    <thead>
        <tr>
            <th>JUEZ</th>
            <th>SECRETARIO</th>
            <th>PISTA</th>
            <th>GRUPOS</th>
            <th>CATEGORIAS</th>
            <th></th> 
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $asiganaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($asig->juez->nombre); ?></td>
            <td><?php echo e($asig->secretario->name); ?></td>
            <td><?php echo e($asig->num_pista); ?></td>
            <td><?php echo e(str_replace(['[',']', '"'],' ' , $asig->grupos)); ?></td>
            <td><?php echo e(str_replace(['[',']', '"'],' ' , $asig->categorias)); ?></td>
            <td>
                <a href="<?php echo e(url('Juez/planillaPDF', [$asig->evento_id, ($asig->estado == 1)? $asig->num_pista : 0])); ?>" class="btn btn-icon btn-info" target="_target" title="Planilla">
                    <i class="fa fa-list"></i>
                </a>
                <a href="<?php echo e(url('Juez/bestingPDF', [$asig->evento_id, ($asig->estado == 1)? $asig->num_pista : 0])); ?>" class="btn btn-icon btn-dark" target="_target" title="besting">
                    <i class="fa fa-user"></i>
                </a>
                <a href="<?php echo e(url('Evento/ranking', [$asig->evento_id, ($asig->estado == 1)? $asig->num_pista : 0])); ?>" class="btn btn-icon btn-primary">
                    <i class="flaticon-map"></i>
                </a>

                <?php if($asig->estado == 2): ?>
                    <button type="button" class="btn btn-icon btn-warning" onclick="agregarCategoria('<?php echo e($asig->id); ?>', '<?php echo e($asig->juez->nombre); ?>')">
                        <i class="fa fa-plus"></i>
                    </button>
                <?php endif; ?>

                <button type="button" class="btn btn-icon btn-danger" onclick="eliminaAsigancion('<?php echo e($asig->id); ?>', '<?php echo e($asig->juez->nombre); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="text-danger">No tiene Jueces Asginados</h3>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\kcb\resources\views/evento/ajaxListadoAsignacion.blade.php ENDPATH**/ ?>