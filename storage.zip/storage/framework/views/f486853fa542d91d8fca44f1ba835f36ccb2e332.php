
<h5 class="text-primary text-center">CALIFICACIONES</h5>
<form action="" id="formularioEditaCalificacionEjemplar">
    <input type="hidden" value="<?php echo e($ejemplar_evento->id); ?>" name="ejemplar_evento_id_edita_calificacion">
    <input type="hidden" value="<?php echo e($pista); ?>" name="pista_edita_calificacion">
    <table class="table text-center">
        <thead>
            <tr>
                <th>Numero</th>
                <th>Calificacion</th>
                <th>Lugar</th>
                <?php if($ejemplar_evento->categoria_pista_id == 5 || $ejemplar_evento->categoria_pista_id == 6 || $ejemplar_evento->categoria_pista_id == 7 || $ejemplar_evento->categoria_pista_id == 8): ?>
                    <th>Puntos</th>
                <?php endif; ?>
                <?php if($ganador): ?>
                    <th>certificado</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <h3 class="text-info"><?php echo e(($calificacion)? $calificacion->numero_prefijo : $ejemplar_evento->numero_prefijo); ?></h3>
                </td>
                <td>
                    
                    <select name="calificacion_ejemplar" id="calificacion_ejemplar" class="form-control">
                        <option value="">Sin Calificacion</option>
                        <option <?php echo e(($calificacion)? (($calificacion->calificacion == 'Excelente')? 'selected' : '') : ''); ?> value="Excelente">Excelente</option>
                        <option <?php echo e(($calificacion)? (($calificacion->calificacion == 'Muy Bueno')? 'selected' : '') : ''); ?> value="Muy Bueno">Muy Bueno</option>
                        <option <?php echo e(($calificacion)? (($calificacion->calificacion == 'Bueno')? 'selected' : '') : ''); ?> value="Bueno">Bueno</option>
                        <option <?php echo e(($calificacion)? (($calificacion->calificacion == 'Descalificado')? 'selected' : '') : ''); ?> value="Descalificado">Descalificado</option>
                        <option <?php echo e(($calificacion)? (($calificacion->calificacion == 'Ausente')? 'selected' : '') : ''); ?> value="Ausente">Ausente</option>
                        <option <?php echo e(($calificacion)? (($calificacion->calificacion == 'Dispenzado')? 'selected' : '') : ''); ?> value="Dispenzado">Dispenzado</option>
                    </select>
                </td>
                <td>
                    
                    <select name="lugar_ejemplar" id="lugar_ejemplar" class="form-control">
                        <option value="">Sin lugar</option>
                        <option <?php echo e(($calificacion)? (($calificacion->lugar == 1)? 'selected' : '') : ''); ?> value="1">Primero</option>
                        <option <?php echo e(($calificacion)? (($calificacion->lugar == 2)? 'selected' : '') : ''); ?> value="2">Segundo</option>
                        <option <?php echo e(($calificacion)? (($calificacion->lugar == 3)? 'selected' : '') : ''); ?> value="3">Tercero</option>
                        <option <?php echo e(($calificacion)? (($calificacion->lugar == 4)? 'selected' : '') : ''); ?> value="4">Cuarto</option>
                        <option <?php echo e(($calificacion)? (($calificacion->lugar == 5)? 'selected' : '') : ''); ?> value="5">Quinto</option>
                    </select>
                </td>
                <?php if($ejemplar_evento->categoria_pista_id == 5 || $ejemplar_evento->categoria_pista_id == 6 || $ejemplar_evento->categoria_pista_id == 7 || $ejemplar_evento->categoria_pista_id == 8): ?>
                    <td>
                        <div class="row">
                            <div class="col-md-8">
                                <select name="certificacion_cacb_puntos" id="certificacion_cacb_puntos" class="form-control">
                                    <option value="">Seleccione</option>
                                    <option <?php echo e(($ganador)? (($ganador->puntos == '1')? 'selected' : '') : ''); ?> value="1">1</option>
                                    <option <?php echo e(($ganador)? (($ganador->puntos == '2')? 'selected' : '') : ''); ?> value="2">2</option>
                                    <option <?php echo e(($ganador)? (($ganador->puntos == '3')? 'selected' : '') : ''); ?> value="3">3</option>
                                    <option <?php echo e(($ganador)? (($ganador->puntos == '4')? 'selected' : '') : ''); ?> value="4">4</option>
                                    <option <?php echo e(($ganador)? (($ganador->puntos == '5')? 'selected' : '') : ''); ?> value="5">5</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <p></p>
                                <div class="form-group">
                                    <div class="checkbox-inline">
                                        <label class="checkbox checkbox-lg">
                                            <input type="checkbox" <?php echo e(($ganador)? (($ganador->estado == 1)? 'checked' :'') : ''); ?> name="certificacion_cacb"/>
                                            <span></span>
                                            CACB
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                <?php endif; ?>
                <?php if($ganador): ?>
                    <td>
                        <?php
                            if($ganador->categoria_id == 2 || $ganador->categoria_id == 11)
                                echo "<h3 class='text-info'>CCCB</h3>";
                            elseif($ganador->categoria_id == 3 || $ganador->categoria_id == 4)
                                echo "<h3 class='text-info'>CJCB</h3>";
                            elseif($ganador->categoria_id == 12 || $ganador->categoria_id == 13)
                                echo "<h3 class='text-info'>CJCGB</h3>";
                            elseif($ganador->categoria_id == 5 || $ganador->categoria_id == 6 || $ganador->categoria_id == 7 || $ganador->categoria_id == 8)
                                if($ganador->estado == 1){
                                    echo "<h3 class='text-info'>CACB</h3>";
                                }
                            elseif($ganador->categoria_id == 9 || $ganador->categoria_id == 10)
                                echo "<h3 class='text-info'>CGCB</h3>";
                            elseif($ganador->categoria_id == 9 || $ganador->categoria_id == 10)
                                echo "<h3 class='text-info'>CACV</h3>";

                        ?>
                    </td>
                <?php endif; ?>
            </tr>
        </tbody>
    </table>

    <hr>
    <h5 class="text-primary text-center">MEJOR VENCEDOR DE CATEGORIA</h5>
    <div class="row">
        <div class="col-md-4">
            <p style="padding-top: 20px;"></p>
            <div class="form-group">
                <div class="checkbox-inline">
                    <label class="checkbox checkbox-lg">
                    <input type="checkbox" <?php echo e(($ganador)? (($ganador->mejor_escogido == "Si")? 'checked' : '') : ''); ?> name="mejor_categoria_hembra_macho"/>
                    <span></span>
                        <?php
                            $categoria = '';

                            if($ganador){
                                if($ganador->mejor_escogido == "Si"){
                                    if($ganador->categoria_id == 2 || $ganador->categoria_id == 11){
                                        $categoria  = "Cachorro";
                                    }elseif($ganador->categoria_id == 3 || $ganador->categoria_id == 4 || $ganador->categoria_id == 12 || $ganador->categoria_id == 13){
                                        $categoria  = "Joven";
                                    }elseif($ganador->categoria_id == 5 || $ganador->categoria_id == 6 || $ganador->categoria_id == 7 || $ganador->categoria_id == 8 || $ganador->categoria_id == 9 || $ganador->categoria_id == 10 || $ganador->categoria_id == 14 || $ganador->categoria_id == 15){
                                        $categoria  = "Adulto";
                                    }elseif($ganador->categoria_id == 16 || $ganador->categoria_id == 17){
                                        $categoria  = "Veterano";
                                    }
                                }
                            }else{
                                
                            }

                            if($calificacion){
                                if($calificacion->sexo == 'Macho')
                                    echo "Mejor de categoria Macho";
                                else
                                    echo "Mejor de categoria Hembra";
                            }else{
                                echo "Mejor de categoria ".$ejemplar_evento->sexo;
                            }
                        ?>
                    </label>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <p style="padding-top: 20px;"></p>
            <div class="form-group">
                <div class="checkbox-inline">
                    <label class="checkbox checkbox-lg">
                    <input type="checkbox" <?php echo e(($calificacion && $ganador)? (($calificacion->sexo == 'Macho')? (($ganador->mejor_macho == "Si")? 'checked' : '') : (($ganador->mejor_hembra == "Si")? 'checked' : '')) : ''); ?> name="mejor_hembra_macho"/>
                    <span></span>
                        <?php
                            if($calificacion){
                                if($calificacion->sexo == 'Macho')
                                    echo "Mejor Macho";
                                else
                                    echo "Mejor Hembra";
                            }else{
                                echo "Mejor ".$ejemplar_evento->sexo;
                            }
                        ?>
                    </label>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <?php if($ejemplar_evento->categoria_pista_id != 1 && $ejemplar_evento->categoria_pista_id != 2 && $ejemplar_evento->categoria_pista_id != 3 && $ejemplar_evento->categoria_pista_id != 4 && $ejemplar_evento->categoria_pista_id != 11 && $ejemplar_evento->categoria_pista_id != 12 && $ejemplar_evento->categoria_pista_id != 13): ?>
                <p style="padding-top: 20px;"></p>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="checkbox-inline">
                                <label class="checkbox checkbox-lg">
                                    <input type="checkbox" <?php echo e(($ganador)? (($ganador->certificacionCLACAB == "Si")? 'checked' :'') : ''); ?> name="certificacion_clacab"/>
                                    <span></span>
                                    CLACAB
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="checkbox-inline">
                                <label class="checkbox checkbox-lg">
                                    <input type="checkbox" <?php echo e(($ganador)? (($ganador->certificacionCACIB == "Si")? 'checked' :'') : ''); ?> name="certificacion_cacib"/>
                                    <span></span>
                                    CACIB
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <hr>

    <div class="row">
        <div class="col-md-4">
            <h4 class="text-primary text-center">Calificacion de cachorro</h4>
            <select name="mejor_raza_cachorro" id="mejor_raza_cachorro" class="form-control" <?php echo e(($ejemplar_evento->categoria_pista_id == 2 || $ejemplar_evento->categoria_pista_id == 11)? "" : "disabled"); ?>>
                <option value="">Seleccione</option>
                <option <?php echo e(($calificacion && $ganador)? (($ganador->mejor_escogido == "Si")? (($ganador->mejor_cachorro == "Si")? 'selected' : '') : '') : ''); ?> value="mejor_cachorro">Mejor Cachorro</option>
                <option <?php echo e(($calificacion && $ganador)? (($ganador->mejor_escogido == "Si")? (($ganador->sexo_opuesto_cachorro == "Si")? 'selected' : '') : '') : ''); ?> value="sexoopuesto_cachorro">Sexo Opuesto</option>
            </select>
        </div>
        <div class="col-md-4">
            <h4 class="text-primary text-center">Calificacion de joven</h4>
            <select name="mejor_raza_joven" id="mejor_raza_joven" class="form-control" <?php echo e(($ejemplar_evento->categoria_pista_id == 3 || $ejemplar_evento->categoria_pista_id == 4 || $ejemplar_evento->categoria_pista_id == 12 || $ejemplar_evento->categoria_pista_id == 13)? '' : 'disabled'); ?>>
                <option value="">Seleccione</option>
                <option <?php echo e(($calificacion && $ganador)? (($ganador->mejor_escogido == "Si")? (($ganador->mejor_joven == "Si")? 'selected' : '') : '') : ''); ?> value="mejor_joven">Mejor Joven</option>
                <option <?php echo e(($calificacion && $ganador)? (($ganador->mejor_escogido == "Si")? (($ganador->sexo_opuesto_joven == "Si")? 'selected' : '') : '') : ''); ?> value="sexoopuesto_joven">Sexo opuesto</option>
            </select>
        </div>
        <div class="col-md-4">
            <h4 class="text-primary text-center">Calificacion de raza</h4>
            <select name="mejor_raza_raza" id="mejor_raza_raza" class="form-control" <?php echo e(($ejemplar_evento->categoria_pista_id == 3 || $ejemplar_evento->categoria_pista_id == 4 || $ejemplar_evento->categoria_pista_id == 12 || $ejemplar_evento->categoria_pista_id == 13 || $ejemplar_evento->categoria_pista_id == 5 || $ejemplar_evento->categoria_pista_id == 6 || $ejemplar_evento->categoria_pista_id == 7 || $ejemplar_evento->categoria_pista_id == 8 || $ejemplar_evento->categoria_pista_id == 9 || $ejemplar_evento->categoria_pista_id == 10 || $ejemplar_evento->categoria_pista_id == 11 || $ejemplar_evento->categoria_pista_id == 14 || $ejemplar_evento->categoria_pista_id == 15)? '' : ''); ?>>
                <option value="">Seleccione</option>
                <option <?php echo e(($calificacion && $ganador)? (($ganador->mejor_escogido == "Si")? (($ganador->mejor_raza == "Si")? 'selected' : '') : '') : ''); ?> value="mejor_raza">Mejor Raza</option>
                <option <?php echo e(($calificacion && $ganador)? (($ganador->mejor_escogido == "Si")? (($ganador->sexo_opuesto_raza == "Si")? 'selected' : '') : '') : ''); ?> value="sexoopuesto_raza">Sexo opuesto</option>
            </select>
        </div>
    </div>
</form>

<br>

<div class="row">
    <div class="col-md-12">
        <button class="btn btn-success btn-block" onclick="editaCalificacion()">Guardar</button>
    </div>
</div>




<?php /**PATH C:\laragon\www\kcb\resources\views/evento/ajaxCalificacionEjemplar.blade.php ENDPATH**/ ?>