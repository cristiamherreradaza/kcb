

<?php $__env->startSection('metadatos'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Modal-->



<!--begin::Card-->
<div class="card card-custom gutter-b">
    <div class="card-header flex-wrap py-3">
        <div class="card-title">
            <h3 class="card-label">FORMULARIO DE PROPIETARIOS
            </h3>
        </div>
        <div class="card-toolbar">
        </div>
    </div>

    <div class="card-body">
        <form action="<?php echo e(url('User/guardaPropietario')); ?>" method="POST" id="formulario-usuarios">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Nombre y Apellido Completo
                            <span class="text-danger">*</span></label>
                        <input type="hidden" class="form-control" id="user_id" name="user_id" value="<?php echo e(($user!=null)?$user->id:''); ?>" />
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(($user!=null)?$user->name:''); ?>" required />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Correo
                            <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e(($user!=null)?$user->email:''); ?>" onfocusout="validaEmail()" required />
                        <span class="form-text text-danger" id="msg-error-email" style="display: none;">Correo duplicado, cambielo!!!</span>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Fecha de Nacimiento
                            <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo e(($user!=null)?$user->fecha_nacimiento:''); ?>" required />
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Cedula
                            <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="ci" name="ci"
                            title="El numero no puede exeder mas de 15 digitos" value="<?php echo e(($user!=null)?$user->ci:''); ?>" onfocusout="validaCedula()" required />
                            <span class="form-text text-danger" id="msg-error-cedula" style="display: none;">Cedula duplicado, cambielo!!!</span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Genero
                            <span class="text-danger">*</span></label>
                        <select name="genero" id="genero" class="form-control">
                            <option value="Masculino" <?php echo e(($user != null && $user->genero=='Masculino')?'selected':''); ?>>Masculino</option>
                            <option value="Femenino" <?php echo e(($user != null && $user->genero=='Femenino')?'selected':''); ?>>Femenino</option>
                            <option value="Otros" <?php echo e(($user != null && $user->genero=='Otros')?'selected':''); ?>>Otros</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Celular
                            <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="celulares" name="celulares" value="<?php echo e(($user!=null)?$user->celulares:''); ?>" required />
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-7">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Direccion
                            <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="direccion" name="direccion" value="<?php echo e(($user!=null)?$user->direccion:''); ?>" required />
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Departamento

                            <span class="text-danger">*</span></label>
                        <select name="departamento" id="departamento" class="form-control">
                            <option value="La Paz" <?php echo e(($user != null && $user->departamento=='La Paz')?'selected':''); ?> >La Paz</option>
                            <option value="Oruro" <?php echo e(($user != null && $user->departamento=='Oruro')?'selected':''); ?> >Oruro</option>
                            <option value="Potosi" <?php echo e(($user != null && $user->departamento=='Potosi')?'selected':''); ?> >Potosi</option>
                            <option value="Cochabamba" <?php echo e(($user != null && $user->departamento=='Cochabamba')?'selected':''); ?> >Cochabamba</option>
                            <option value="Chuquisaca" <?php echo e(($user != null && $user->departamento=='Chuquisaca')?'selected':''); ?> >Chuquisaca</option>
                            <option value="Tarija" <?php echo e(($user != null && $user->departamento=='Tarija')?'selected':''); ?> >Tarija</option>
                            <option value="Pando" <?php echo e(($user != null && $user->departamento=='Pando')?'selected':''); ?> >Pando</option>
                            <option value="Beni" <?php echo e(($user != null && $user->departamento=='Beni')?'selected':''); ?> >Beni</option>
                            <option value="Santa Cruz" <?php echo e(($user != null && $user->departamento=='Santa Cruz')?'selected':''); ?> >Santa Cruz</option>
                            
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="exampleInputPassword1">Tipo
                            <span class="text-danger">*</span></label>
                        <select name="socio" id="socio" class="form-control">
                            <?php if($user == null): ?>
                                <option value="Socio">Socio</option>
                                <option value="Criador">Criador</option>
                                <option value="Socio Usufructuario">Socio Usufructuario</option>
                            <?php else: ?>
                                <option value="Socio" <?php echo e(($user->tipo=='Socio')?'selected':''); ?>>Socio</option>
                                <option value="Criador" <?php echo e(($user->tipo=='Criador')?'selected':''); ?>>Criador</option>
                                <option value="Socio Usufructuario" <?php echo e(($user->tipo=='Socio Usufructuario')?'selected':''); ?>>Socio Usufructuario</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6"><button type="button" class="btn btn-sm btn-success btn-block" onclick="crear()">GUARDAR</button></div>
                <div class="col-md-6"><button type="button" class="btn btn-sm btn-dark btn-block" onclick="volver()">VOLVER</button></div>
            </div>
        </form>
    </div>
</div>
<!--end::Card-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    function crear()
    {
        if($('#formulario-usuarios')[0].checkValidity()){
            $('#formulario-usuarios').submit();
            Swal.fire("Excelente!", "Registro Guardado!", "success");
        }else{
            $('#formulario-usuarios')[0].reportValidity()
        }
    }

    function volver(){
        window.location.href = "<?php echo e(url('User/listadoPropietario')); ?>";
    }

    function validaEmail()
    {
        let email = $("#email").val();

        $.ajax({
            url: "<?php echo e(url('User/validaEmail')); ?>",
            data: {email: email},
            type: 'POST',
            success: function(data) {
                // console.log(data.vEmail);     
                if(data.vEmail > 0){
                    $("#msg-error-email").show();
                }else{
                    $("#msg-error-email").hide();
                }
            }
        });
    }

    function validaCedula(){
        let cedula = $("#ci").val();

        $.ajax({
            url: "<?php echo e(url('User/validaCedula')); ?>",
            data: {cedula: cedula},
            type: 'POST',
            success: function(data) {
                // console.log(data.vEmail);     
                if(data.vCedula > 0){
                    $("#msg-error-cedula").show();
                }else{
                    $("#msg-error-cedula").hide();
                }
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/propietarios/formulario.blade.php ENDPATH**/ ?>