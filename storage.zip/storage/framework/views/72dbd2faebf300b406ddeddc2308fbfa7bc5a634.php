


<?php $__env->startSection('metadatos'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!--begin::Card-->
	<div class="card card-custom gutter-b">
		<div class="card-header flex-wrap py-3">
			<div class="card-title">
				<h3 class="card-label">PERMISOS DE PERFILES 
				</h3>
			</div>
			<div class="card-toolbar">
				<!--begin::Button-->
				
				<!--end::Button-->
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-8">
				<div class="card-header flex-wrap py-3">
					<form action="" method="" id="formulario-permiso">
						<div class="form-group">
							
							<select name="perfil" id="perfil" class="form-control" required>
								<option value="">Seleccione un perfil</option>
								<?php $__currentLoopData = $perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($p->id); ?>"><?php echo e($p->nombre); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</form>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card-header flex-wrap py-3">
					<button class="btn btn-primary btn-block" type="button" onclick="seleccionaPerfil()">Buscar</button>
				</div>
			</div>
		</div>
		
		<div class="card-body">
			<div class="row">
				<div class="col-md-12">
					<div id="contenido">

					</div>
				</div>
			</div>
		</div>
	</div>
	<!--end::Card-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
    <script type="text/javascript">

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		function seleccionaPerfil(){
			if($('#formulario-permiso')[0].checkValidity()){
				let perfil = $("#perfil").val();
				$.ajax({
					url: "<?php echo e(url('User/ajaxBuscaPermisos')); ?>",
					data: {
						perfil_id: perfil
					},
					type: 'POST',
					success: function(data) {
						$("#contenido").html(data);
					}
				});
			}else{
				$('#formulario-permiso')[0].reportValidity()
			}
		}

		function cambiaEstado(id, perfil){
			$.ajax({
				url: "<?php echo e(url('User/cambiaEstadoMenuPerfil')); ?>",
				data: {
					perfil_id: perfil,
					menu_id: id
				},
				type: 'POST',
				success: function(data) {
					$("#contenido").html(data);
				}
			});
		}
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/user/listaPermisos.blade.php ENDPATH**/ ?>