
<html>
<head>
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<style type="text/css">
    @page  {
        size: landscape;
        margin: 0;
    }
    body{
        width: 100%;
        margin: 0;
        font-family: Arial, Helvetica, sans-serif;
    }
    #enlaces a{
        background-color:yellow;
    }
    /* #datos-ejemplar-1{
        position: absolute;
        top: 90px;
        left: 310px;
        width: 700px;
    }
    #table-datos-1{
        width: 100%;
    }
    #color{
        width: 180px;
    }
    #fecha-naciento{
        width: 150px;
    }
    #consagnidad{
        width: 80px;
    }
    #propietario{
        width: 400px;
        font-size: 15px;
        padding: 5px 0px 5px 0px;
    }
    #direccion{
        padding: 10px 0px 7px 0px;
    }
    #telefono{
        padding: 3px 0px 0px 0px;
    }
    #email{
        padding: 0px 0px 0px 60px;
    }
    table tr td{
        text-align: left;
    }
    td{
        font-size: 17px;
        padding: 0;
        margin: 0;
        color: #0414ff;
        font-weight: bold;
    }
    .impor-1{
        font-size: 22px;
    }
    .titulos{
        height: 33px;
    }
    #datos-ejemplar-2{
        position: absolute;
        top: 86px;
        left: 1050px;
        color: #0414ff;
        font-weight: bold;
        width: 550px;
        padding:0%;
    }
    #arbol-genealogio{
        position: absolute;
        top: 262px;
        left: 220px;
        color: #0414ff;
        font-weight: bold;
        width:1340px;   
        height: 560px;   
    }
    #tabla-genealogio{
        width:100%;
    }
    .padres{
        position: absolute;
        width:290px;
        height: 243px;
        font-size: 18px;
    }
    .padre_1{
        top: -5px;
    }
    .padre_2{
        top: 245px;
    }
    .abuelos{
        position: absolute;
        font-size: 12px;
        left: 310px;
        width:250px;
        height: 123px;
    }
    .abuelo_1{
        top:-3px;
    }
    .abuelo_2{
        top: 123px;
    }
    .abuelo_3{
        top: 245px;
    }
    .abuelo_4{
        top: 370px;
    }
    .tercera_generaciones{
        position: absolute;
        font-size: 11px;
        height: 60px;
        width:300px;
        left: 570px;
    }
    .tg_1{
        top:0px;
    }
    .tg_2{
        top:63px;
    }

    .tg_3{
        top:123px;
    }
    .tg_4{
        top:183px;
    }
    .tg_5{
        top: 246px;
    }
    .tg_6{
        top:308px;
    }
    .tg_7{
        top:368px;
    }
    .tg_8{
        top:430px;
    }
    .cuarta_generaciones{
        position: absolute;
        width: 450px;
        height: 30px;
        font-size: 10px;
        left: 876px;
    }
    .cg_1{
        top: -5px;
    }
    .cg_2{
        top: 30px;
    }
    .cg_3{
        top: 61px;
    }
    .cg_4{
        top: 93px;
    }
    .cg_5{
        top: 124px;
    }
    .cg_6{
        top: 154px;
    }
    .cg_7{
        top: 185px;
    }
    .cg_8{
        top: 216px;
    }
    .cg_9{
        top: 247px;
    }
    .cg_10{
        top: 279px;
    }
    .cg_11{
        top: 310px;
    }
    .cg_12{
        top: 340px;
    }
    .cg_13{
        top: 371px;
    }
    .cg_14{
        top: 402px;
    }
    .cg_15{
        top: 432px;
    }
    .cg_16{
        top: 465px;
    } 
    .lechigada{
        position: absolute;
        font-size: 15px;
        bottom: 155px;
        left: 600px;
        color: #0414ff;
        font-weight: bold;
    }
    */
    #certificado{
        padding: 15px 20px 0px 160px;
        width: 85%;
    }
    .examenes-apto-cria{
        position: absolute;
        top: 105px;
        font-size: 12px;
        left: 270px;
        color: #0414ff;
        font-weight: bold;
    }
    .espacio{
        padding:0px 55px 0px 55px;
    }
    .examenes-displacia-cadera{
        position: absolute;
        top: 205px;
        font-size: 12px;
        left: 275px;
        color: #0414ff;
        font-weight: bold;
    }
    .examenes-displacia-codos{
        position: absolute;
        top: 205px;
        font-size: 12px;
        left: 440px;
        color: #0414ff;
        font-weight: bold;
    }
    .test-adn{
        position: absolute;
        top: 365px;
        font-size: 12px;
        left: 350px;
        color: #0414ff;
        font-weight: bold;
    }
    .tramsferencias{
        position: absolute;
        top: 350px;
        font-size: 12px;
        left: 275px;
        color: #0414ff;
        font-weight: bold;
        /* line-height : 17px; */
    }
    .spacio-transferencia{
        padding: 70px 0px 0px 0px;
    }
    .datos-certificado{
        left: -60px;
        top: -26px;
        position: absolute;
        background-color: yellow;
        line-height : 16px;
        /* opacity: 0.5; */
        /* left: 10px; */
    }
    
</style>

<body onload="shrink()">
    <div id="bloque-certificado">
        
        <img src="<?php echo e(url('img/certificado_2.jpg')); ?>" id="certificado" alt="No hay imagen">
        <div class="datos-certificado">
            <div class="examenes-apto-cria">
                <?php
                    $examenMascota = App\ExamenMascota::where('ejemplar_id','=',$ejemplar->id)
                                                        ->where('examen_id','=',2)
                                                        ->first();
                                                        // dd($examenMascota);
                    if($examenMascota){
                        echo date( 'd/m/Y',strtotime($examenMascota->fecha_examen))."<span class='espacio'></span>".$examenMascota->numero_formulario."<br>".$examenMascota->revisor;
                    }
                ?>
            </div>
            <div class="examenes-displacia-cadera">
                <?php
                    $examenMascota = App\ExamenMascota::where('ejemplar_id','=',$ejemplar->id)
                                                        ->where('examen_id','=',1)
                                                        ->first();
                                                        // dd($examenMascota);
                    if($examenMascota){
                        echo date( 'd/m/Y',strtotime($examenMascota->fecha_examen))."<br><br>".$examenMascota->resultado."<br>".$examenMascota->revisor;
                    }
                ?>
            </div>
            <div class="examenes-displacia-codos">
                <?php
                    $examenMascota = App\ExamenMascota::where('ejemplar_id','=',$ejemplar->id)
                                                        ->where('examen_id','=',4)
                                                        ->first();
                                                        // dd($examenMascota);
                    if($examenMascota){
                        echo date( 'd/m/Y',strtotime($examenMascota->fecha_examen))."<br><br>".$examenMascota->resultado."<br>".$examenMascota->revisor;
                    }
                ?>
            </div>
            
            <div class="tramsferencias">
                <?php
                    $tramsferencias = App\Transferencia::where('ejemplar_id','=',$ejemplar->id)
                                                        // ->where('examen_id','=',4)
                                                        ->get();
                                                        // dd($examenMascota);
                    foreach ($tramsferencias as $t){
                        // echo 'como es';
                        echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp".$t->propietario->name."<br>";
                        echo date( 'd/m/Y',strtotime($t->fecha_transferencia))."<span class='espacio'></span>".$t->pais_destino.'<br>';
                        echo $t->propietario->direccion."<br>";
                        echo $t->propietario->celulares;
                        echo '<div class="spacio-transferencia"></div>';
                    }
                    // if($examenMascota){
                    //     echo date( 'd/m/Y',strtotime($examenMascota->fecha_examen))."<br><br>".$examenMascota->resultado."<br>".$examenMascota->revisor;
                    // }
                ?>
            </div>
        </div>
        
        
        
        
    </div>
    <div id="enlaces">
        <a href="<?php echo e(url('Ejemplar/informacion')); ?>/<?php echo e($ejemplar->id); ?>">Volver</a>
        <a href="#" onclick="imprimir()">Imprimir</a>
        <a href="<?php echo e(url('Ejemplar/certificadoRosadoAdelante')); ?>/<?php echo e($ejemplar->id); ?>">Siguiente</a>
        
    </div>
</body>
</html>


<script src="<?php echo e(asset('assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/qrcode.min.js')); ?>"></script>

<script type="text/javascript">
    function imprimir(){
        $('#certificado').hide();
        $('#enlaces').hide();
        window.print();
        $('#enlaces').show();
        $('#certificado').show();
    }
    // let cadenaQr = "BEGIN:VCALENDAR"+"%0D%0A"+
    //                    "VERSION:1.0"+"%0D%0A"+
    //                    "BEGIN:VEVENT"+"%0D%0A"+
    //                    "DTSTART:" + "19960401T090000" +"%0D%0A"+
    //                    "DTEND:" + "19960401T043000" +"%0D%0A"+
    //                    "SUMMARY:" + "Your Proposal Review"+"%0D%0A"+
    //                    "DESCRIPTION:" + "Steve and John to review newest proposal material"+"%0D%0A"+
    //                    "END:VEVENT"+"%0D%0A"+
    //                    "END:VCALENDAR"+"%0D%0A";
    // cadenaQr = decodeURIComponent(cadenaQr);

    // let cadenaQr = holas;
    // let cadenaQr = "KCB: <?php echo e($ejemplar->kcb); ?>\nNombre: <?php echo e(trim($ejemplar->nombre_completo)); ?>\nRaza: <?php echo e(trim($ejemplar->raza->nombre)); ?>\nN. Tatuaje: <?php echo e($ejemplar->num_tatuaje); ?>\nChip: <?php echo e($ejemplar->chip); ?>\nSexo: <?php echo e($ejemplar->sexo); ?>\nF. Nacimeinto: <?php echo e($ejemplar->fecha_nacimiento); ?>\n";
    // let cadenaQr = "KCB: <?php echo e($ejemplar->kcb); ?>\nNombre: <?php echo e(trim($ejemplar->nombre_completo)); ?>\nRaza: <?php echo e(trim($ejemplar->raza->nombre)); ?>\nN. Tatuaje: <?php echo e($ejemplar->num_tatuaje); ?>\nChip: <?php echo e($ejemplar->chip); ?>\nSexo: <?php echo e($ejemplar->sexo); ?>\n https://kcb.org.bo/";

    // var qrcode = new QRCode("qrcode", {
    //     text: cadenaQr,
    //     width: 110,
    //     height: 110,
    //     colorDark : "#000000",
    //     colorLight : "#ffffff",
    //     correctLevel : QRCode.CorrectLevel.H
    // });

    $(window).keydown(function(event) { 
        if(event.ctrlKey && event.keyCode == 80) { 
            var certificado  = document.getElementById("certificado");
            $('#certificado').hide();
            $('#enlaces').hide();
            window.print();
            $('#certificado').show();
            $('#enlaces').show();
            certificado.style.width = "85%";
            event.preventDefault(); 
        } 
    });

    // padres
    function shrink()
    {
        /*******************  PADRES  *************************/

        var textDivs = document.getElementsByClassName("padres");
        var textDivsLength = textDivs.length;
        // console.log(textDivsLength);

        // Recorre todos los divs dinámicos de la página.
        for(var i=0; i<textDivsLength; i++) {

            var textDiv = textDivs[i];

            // Recorre todos los tramos dinámicos dentro del div
            var textSpan = textDiv.getElementsByClassName("padres1")[0];

            // console.log(textSpan);
            // console.log(textSpan.style);
            
            // Use la misma lógica de bucle que antes
            textSpan.style.fontSize = 18;

            // console.log(textSpan.style.fontSize);
            // var i = 1 ;
            // console.log(textSpan.offsetWidth);
            // console.log(textDiv.offsetWidth);
            while(textSpan.offsetHeight > textDiv.offsetHeight)
            {
                textSpan.style.fontSize = parseInt(textSpan.style.fontSize) - 1;
                // i++;
                // console.log(textSpan.style.fontSize);
                // console.log(i);
            }

            while(textSpan.offsetWidth > textDiv.offsetWidth)
            {
                textSpan.style.fontSize = parseInt(textSpan.style.fontSize) - 1;
                // i++;
                // console.log(textSpan.style.fontSize);
                // console.log(i);
            }

        }


        /*******************  ABUELOS  *************************/
        var AbuelotextDivs = document.getElementsByClassName("abuelos");
        var AbuelotextDivsLength = AbuelotextDivs.length;

        for(var i=0; i<AbuelotextDivsLength; i++) {

            var AbuelotextDiv = AbuelotextDivs[i];

            var AbuelotextSpan = AbuelotextDiv.getElementsByClassName("abuelos1")[0];

            AbuelotextSpan.style.fontSize = 18;

            while(AbuelotextSpan.offsetHeight > AbuelotextDiv.offsetHeight)
            {
                AbuelotextSpan.style.fontSize = parseInt(AbuelotextSpan.style.fontSize) - 1;
            }

            while(AbuelotextSpan.offsetWidth > AbuelotextDiv.offsetWidth)
            {
                AbuelotextSpan.style.fontSize = parseInt(AbuelotextSpan.style.fontSize) - 1;
            }

        }


        /*******************  TERCERA GENERACION  *************************/
        var AbuelotextDivs = document.getElementsByClassName("tercera_generaciones");
        var AbuelotextDivsLength = AbuelotextDivs.length;

        for(var i=0; i<AbuelotextDivsLength; i++) {

            var AbuelotextDiv = AbuelotextDivs[i];

            var AbuelotextSpan = AbuelotextDiv.getElementsByClassName("tercera_generaciones1")[0];

            AbuelotextSpan.style.fontSize = 18;

            while(AbuelotextSpan.offsetHeight > AbuelotextDiv.offsetHeight)
            {
                AbuelotextSpan.style.fontSize = parseInt(AbuelotextSpan.style.fontSize) - 1;
            }

            while(AbuelotextSpan.offsetWidth > AbuelotextDiv.offsetWidth)
            {
                AbuelotextSpan.style.fontSize = parseInt(AbuelotextSpan.style.fontSize) - 1;
            }

        }


        /*******************  CUARTA GENERACION  *************************/
        var AbuelotextDivs = document.getElementsByClassName("cuarta_generaciones");
        var AbuelotextDivsLength = AbuelotextDivs.length;

        for(var i=0; i<AbuelotextDivsLength; i++) {

            var AbuelotextDiv = AbuelotextDivs[i];

            var AbuelotextSpan = AbuelotextDiv.getElementsByClassName("cuarta_generaciones1")[0];

            AbuelotextSpan.style.fontSize = 18;

            while(AbuelotextSpan.offsetHeight > AbuelotextDiv.offsetHeight)
            {
                AbuelotextSpan.style.fontSize = parseInt(AbuelotextSpan.style.fontSize) - 1;
            }

            // while(AbuelotextSpan.offsetWidth > AbuelotextDiv.offsetWidth)
            // {
            //     AbuelotextSpan.style.fontSize = parseInt(AbuelotextSpan.style.fontSize) - 1;
            // }

        }

    }

    // abuelos
    // function shrink()
    // {
        

    // }
</script>




<?php /**PATH C:\laragon\www\kcb\resources\views/certificado/certificadoRosadoAdelante.blade.php ENDPATH**/ ?>