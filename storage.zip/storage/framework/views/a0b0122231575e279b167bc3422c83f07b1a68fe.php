<hr>
<h4 class="text-center text-warning" id="cantidad_de_asignacion">
    
</h4>
<hr>
<h2 class="text-success text-center">Ejemplares</h2>
<hr>
<table class="table table-striped" id="table_ejemplres_numeros">
    <thead>
        <tr>
            <th>Numero</th>
            <th>Calificacion</th>
            <th>Mejor Categoria</th>
            <th>Mejor Vencedor</th>
            <th>Mejor Raza</th> 
            <th>Calf. Grupo</th> 
            <th>Podio</th> 
            <th></th> 
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ejemplaresEventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td width="2px"><h3 class="text-primary text-center"><?php echo e($e->numero_prefijo); ?></h3></td>
                <td width="2px">
                    <?php

                        $calificacion = App\Calificacion::where('ejemplares_eventos_id', $e->id)
                                                        ->where('pista', $num_pista)
                                                        ->first();

                        if($calificacion)
                            echo "<span class='text-info text-center'>".$calificacion->calificacion." : ".$calificacion->lugar."</span>";

                    ?>
                </td>
                <td width="2px">
                    <?php
                        $mojorGanador = App\Ganador::where('ejemplar_evento_id', $e->id)
                                                    ->where('pista', $num_pista)
                                                    ->where('mejor_escogido', "Si")
                                                    ->first();
                    ?>
                    <?php if($mojorGanador): ?>
                        <?php if($mojorGanador->categoria_id == 3 || $mojorGanador->categoria_id == 4 || $mojorGanador->categoria_id == 12 || $mojorGanador->categoria_id == 13): ?>
                            <span class='text-info text-center'>Mejor Joven</span>
                        <?php elseif($mojorGanador->categoria_id == 5 || $mojorGanador->categoria_id == 6 || $mojorGanador->categoria_id == 7 || $mojorGanador->categoria_id == 8 || $mojorGanador->categoria_id == 9 || $mojorGanador->categoria_id == 10 || $mojorGanador->categoria_id == 14 || $mojorGanador->categoria_id == 15): ?>
                            <span class='text-info text-center'>Mejor Adulto</span>
                        <?php elseif($mojorGanador->categoria_id == 2 || $mojorGanador->categoria_id == 11): ?>
                            <span class='text-info text-center'>Mejor Cachorro</span>
                        <?php elseif($mojorGanador->categoria_id == 16 || $mojorGanador->categoria_id == 17): ?>
                            <span class='text-info text-center'>Mejor Veterano</span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td width="2px">
                    <?php if($mojorGanador): ?>
                        <?php if($mojorGanador->mejor_macho == "Si"): ?>
                            <span class='text-info text-center'>Mejor Macho</span>
                        <?php else: ?>
                            <span class='text-info text-center'>Mejor Hembra</span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td width="2px">
                    <?php
                        if($mojorGanador){
                            $mejor = '';

                            // cachorros
                            if($mojorGanador->mejor_cachorro == "Si"){
                                $mejor = $mejor." | <span class='text-info text-center'>Mejor Cachorro</span> ";
                            }elseif($mojorGanador->sexo_opuesto_cachorro == "Si"){
                                $mejor = $mejor." | <span class='text-info text-center'>Sexo opuesto</span> ";
                            }

                            // joven
                            if($mojorGanador->mejor_joven == "Si"){
                                $mejor = $mejor." | <span class='text-warning text-center'>Mejor Joven</span> ";
                            }elseif($mojorGanador->sexo_opuesto_joven == "Si"){
                                $mejor = $mejor." | <span class='text-warning text-center'>Sexo opuesto</span> ";
                            }

                            // raza
                            if($mojorGanador->mejor_raza == "Si"){
                                $mejor = $mejor." | <span class='text-success text-center'>Mejor Raza</span> ";
                            }elseif($mojorGanador->sexo_opuesto_raza == "Si"){
                                $mejor = $mejor." | <span class='text-success text-center'>Sexo opuesto</span> ";
                            }

                            echo $mejor;
                        }
                    ?>
                </td>
                <td width="2px">
                    <?php
                        $besting = App\Besting::where('ejemplar_evento_id', $e->id)
                                                ->where('pista', $num_pista)
                                                ->first();

                        if($besting)
                            echo "<span class='text-info text-center'>".$besting->lugar."</span>";

                    ?>
                </td>
                <td>
                    <?php if($besting): ?>
                        <span class='text-info text-center'><?php echo e($besting->lugar_finalista); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <button class="btn btn-warning btn-icon btn-sm" onclick="verDetalleCalificacion('<?php echo e($e->id); ?>', '<?php echo e((($num_pista)? $num_pista : 0)); ?>', '<?php echo e($e->evento_id); ?>')"><i class="fa fa-eye"></i></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3 class="text-danger">No tiene ejemplares</h3>
        <?php endif; ?>
    </tbody>
</table>
<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<script>
    $('#table_ejemplres_numeros').DataTable({
        // order: [[ 0, "desc" ]],
        // searching: false,
        lengthChange: false,
        responsive: true,
        language: {
            url: '<?php echo e(asset('datatableEs.json')); ?>'
        },
    });
</script>
<?php /**PATH C:\laragon\www\kcb\resources\views/evento/ajaxListadoEjemplaresEventos.blade.php ENDPATH**/ ?>