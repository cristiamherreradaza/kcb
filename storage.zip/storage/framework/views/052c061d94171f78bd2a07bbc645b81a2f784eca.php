
<button class="btn btn-primary btn-block" type="button" onclick="BuscaPropietario()">Cedula: <?php echo e($ultimaPersona->ci); ?> Nombre:  <?php echo e($ultimaPersona->name); ?></button>

<script type="text/javascript">
    $(document).ready(function(){
        $('#transferencia_propietario_id').val(<?php echo e($ultimaPersona->id); ?>);
     });
</script><?php /**PATH C:\laragon\www\kcb\resources\views/user/ajaxNuevoPropietario.blade.php ENDPATH**/ ?>