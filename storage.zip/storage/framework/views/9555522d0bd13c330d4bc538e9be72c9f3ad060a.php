<table class="table table-striped">
    <thead>
        <tr>
            <th>FECHA</th>
            <th>EXAMEN</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $examenesEjemplar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($ee->fecha_examen); ?></td>
            <td><?php echo e($ee->examen->nombre); ?></td>
            <td>
                <button type="button" class="btn btn-icon btn-warning" onclick="editaExamen('<?php echo e($ee->id); ?>', '<?php echo e($ee->examen_id); ?>', '<?php echo e($ee->fecha_examen); ?>', '<?php echo e($ee->revisor); ?>', '<?php echo e($ee->resultado); ?>', '<?php echo e($ee->observacion); ?>', '<?php echo e($ee->numero_formulario); ?>', '<?php echo e($ee->dcf); ?>')">
                    <i class="flaticon2-edit"></i>
                </button>
                <button type="button" class="btn btn-icon btn-danger"
                    onclick="eliminaExamen('<?php echo e($ee->id); ?>', '<?php echo e($ee->examen->nombre); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>No tiene examenes</h3>
        <?php endif; ?>
    </tbody>
</table>
<a href="#" class="btn btn-info btn-block" onclick="nuevoExamen()">Nuevo Examen</a>
<?php /**PATH C:\laragon\www\kcb\resources\views/ejemplar/ajaxGuardaExamen.blade.php ENDPATH**/ ?>