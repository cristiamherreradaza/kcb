<link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<table class="table table-bordered table-hover table-striped" id="tabla_criaderos">
    <thead>
        <tr>
            <th>ID</th>
            <th>Propietario</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Celular</th>
            <th>Departamento</th>
            
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $datosCriaderos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php if($cri->criadero && $cri->propietario): ?>
        <tr>
            <td><?php echo e($cri->idProCria); ?></td>
            <td><?php echo e($cri->propietario->name); ?></td>
            <td><?php echo e($cri->criadero->nombre); ?></td>
            <td><?php echo e($cri->criadero->email); ?></td>
            <td><?php echo e($cri->criadero->celulares); ?></td>
            <td><?php echo e($cri->criadero->departamento); ?></td>
            
            <td>
                <button type="button" class="btn btn-icon btn-warning" onclick="edita('<?php echo e($cri->idProCria); ?>')">
                    <i class="flaticon2-edit"></i>
                </button>
                
                <button type="button" class="btn btn-icon btn-danger"
                    onclick="elimina('<?php echo e($cri->idProCria); ?>', '<?php echo e($cri->nombre); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="text-danger">NO EXISTEN CRIADEROS</h3>
        <?php endif; ?>
    </tbody>
    <tbody>
    </tbody>
</table>
<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<script>
    $('#tabla_criaderos').DataTable({
        order: [[ 0, "desc" ]],
        searching: false,
        lengthChange: false,
        responsive: true,
        language: {
            url: '<?php echo e(asset('datatableEs.json')); ?>'
        },
    });
</script>
<?php /**PATH C:\laragon\www\kcb\resources\views/criaderos/ajaxListadoCriadero.blade.php ENDPATH**/ ?>