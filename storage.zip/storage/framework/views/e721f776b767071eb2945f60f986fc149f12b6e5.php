<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    #tabla-datos{
        /* background-color:black; */
        color: black;
        font-size:9px;
        text-align: center;
    }
    
    .tabla_planilla, tabla_planillaTh, tabla_planillaTd{
        border: 1.5px solid black;
        border-collapse: collapse;
    }
    #tabla-datos-cuerpo{
        font-size:10px;
        text-align: left;
        padding:1px;
    }
    #titulo{
        position: absolute;
        margin-top: -30px;
        font-size:20px;
        margin-left: 400px;
    }
    #table-cachorros{
        position: absolute;
        margin-left: 20px;
    }
    #table-joven{
        position: absolute;
        margin-left: 150px;
    }
    #table-jovenCampeon{
        position: absolute;
        margin-left: 267px;
    }
    #table-intermedio{
        position: absolute;
        margin-left: 389px;
    }
    #table-abierta{
        position: absolute;
        margin-left: 506px;
    }
    #table-campeones{
        position: absolute;
        margin-left: 625px;
    }
    #table-grandesCampeones{
        position: absolute;
        margin-left: 742px;
    }
    #table-veteranos{
        position: absolute;
        margin-left: 877px;
    }

    /* HEMBRAS */
    #table-cachorrosHembra{
        position: absolute;
        margin-left: 20px;
        margin-top: 350px;
    }
    #table-jovenHembra{
        position: absolute;
        margin-left: 150px;
        margin-top: 350px;
    }
    #table-jovenCampeonHembra{
        position: absolute;
        margin-left: 267px;
        margin-top: 350px;
    }
    #table-intermedioHembra{
        position: absolute;
        margin-left: 389px;
        margin-top: 350px;
    }
    #table-abiertaHembra{
        position: absolute;
        margin-left: 506px;
        margin-top: 350px;
    }
    #table-campeonesHembra{
        position: absolute;
        margin-left: 625px;
        margin-top: 350px;
    }
    #table-grandesCampeonesHembra{
        position: absolute;
        margin-left: 742px;
        margin-top: 350px;
    }
    #table-veteranosHembra{
        position: absolute;
        margin-left: 877px;
        margin-top: 350px;
    }

    h3 span { 
        display: block; 
        writing-mode: vertical-lr;
        transform: rotate(-90deg);
    }

    #machos{
        margin-left: -20px;
        position: absolute;
        border: solid;
        padding: 5px;
        padding-top: 55px;
        padding-bottom: 55px;
    }

    #cabecera-campeones{
        padding-top: 7px;
        padding-bottom: 6px;
    }
    #hembra{
        margin-left: -20px;
        position: absolute;
        border: solid;
        padding: 5px;
        padding-top: 56px;
        padding-bottom: 56px;
        margin-top: 350px;
    }

    #juez{
        margin-left: -20px;
        position: absolute;
    }
    #lugar{
        position: absolute;
        margin-left:300px;
    }
    #raza{
        position: absolute;
        margin-left:550px;
    }
    #grupo{
        position: absolute;
        margin-left:890px;
    }
    #calificaion{
        width: 60px;
        height: 20px;
    }
    #numero_prefijo{
        width: 20px;
    }
    #tabla-dentroTabla{
        width: 50px;
        font-size:10px;
    }
    #tabla-dentroTablaponderacion{
        height: 20px;
    }
    #tabla-ponderacion{
        margin-left: 50px;
        margin-top: -5px;
    }
</style>
<body>

    <h1 id="titulo">PLANILLA DE RAZA </h1>
    <div class="cabeza-datos">
        

        
        <div id="juez">JUEZ: </div>
        <div id="lugar">LUGAR Y FECHA: <?php echo e(date('d/m/Y')); ?></div>
        <div id="raza">RAZA:</div>
        <div id="grupo">GRUPO: </div>
    </div>

    <br>        

    <div class="planillaMacho">

        <div id="machos">
            <h3>
                <span> O </span>
                <span> H </span>
                <span> C </span>
                <span> A </span>
                <span> M </span>
            </h3>
        </div>

        <div id="table-cachorros">
            <table class="tabla_planilla">
                <thead id="tabla-datos" class="tabla_planilla">
                    <tr>
                        <th colspan="3">CACHORRO <br> 6 a 9 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo" class="tabla_planilla">
                    <tr class="tabla_planilla">
                        <th class="tabla_planilla">Nº</th>
                        <th class="tabla_planilla">Calf.</th>
                        <th class="tabla_planilla">Lugar</th>
                    </tr>
                    <?php
                        $cantidad = count($ejemplaresCachorroAbsolutos);
                    ?>
                    <?php for($i=0 ; $i < 9 ; $i++): ?>
                        <tr>
                            <?php if($i < $cantidad): ?>
                                <th class="tabla_planilla" id="numero_prefijo"><?php echo e($ejemplaresCachorroAbsolutos[$i]->numero_prefijo); ?></th>
                                <?php
                                    $calificaion = App\Juez::ejemplarEventoInscrito($ejemplaresCachorroAbsolutos[$i]->id);
                                ?>
                                <th class="tabla_planilla" id="calificaion"><?php echo e(($calificaion)? $calificaion->calificacion : ''); ?></th>
                                <th class="tabla_planilla"><?php echo e(($calificaion)? $calificaion->lugar : ''); ?></th>
                            <?php else: ?>
                                <th class="tabla_planilla" id="numero_prefijo"><p style="padding-top: 1px;"></p></th>
                                <th class="tabla_planilla" id="calificaion"></th>
                                <th class="tabla_planilla"></th>
                            <?php endif; ?>
                        </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot class="tabla_planilla">
                    <td class="tabla_planilla" colspan="3" style="font-size: 10px;">
                        CCCB
                        <table class="tabla_planilla" id="tabla-ponderacion">
                            <thead class="tabla_planilla" >
                                <tr class="tabla_planilla">
                                    <th  class="tabla_planilla"id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-joven">
            <table class="tabla_planilla">
                <thead  class="tabla_planilla" id="tabla-datos">
                    <tr>
                        <th colspan="3">JOVEN <br> 9 a 18 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo" class="tabla_planilla">
                    <tr>
                        <th class="tabla_planilla">Nº</th>
                        <th class="tabla_planilla">Calf.</th>
                        <th class="tabla_planilla">Lugar</th>
                    </tr>
                    <?php
                        $cantidad = count($ejemplaresJoven);
                    ?>
                    <?php for($i=0 ; $i < 9 ; $i++): ?>
                    <tr class="tabla_planilla">
                        <?php if($i < $cantidad): ?>
                            <th class="tabla_planilla" id="numero_prefijo"><?php echo e($ejemplaresJoven[$i]->numero_prefijo); ?></th>
                            <?php
                                $calificaion = App\Juez::ejemplarEventoInscrito($ejemplaresJoven[$i]->id);
                            ?>
                            <th class="tabla_planilla" id="calificaion"><?php echo e(($calificaion)? $calificaion->calificacion : ''); ?></th>
                            <th class="tabla_planilla"><?php echo e(($calificaion)? $calificaion->lugar : ''); ?></th>
                        <?php else: ?>
                            <th class="tabla_planilla" id="numero_prefijo"><p style="padding-top: 1px;"></p></th>
                            <th class="tabla_planilla" id="calificaion"></th>
                            <th class="tabla_planilla"></th>
                        <?php endif; ?>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CJCB
                        <table class="tabla_planilla" id="tabla-ponderacion">
                            <thead  class="tabla_planilla">
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-jovenCampeon">
            <table class="tabla_planilla">
                <thead id="tabla-datos" class="tabla_planilla">
                    <tr>
                        <th colspan="3">JOVEN CAMPEON <br> 9 a 18 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo" class="tabla_planilla">
                    <tr class="tabla_planilla">
                        <th class="tabla_planilla">Nº</th>
                        <th class="tabla_planilla">Calf.</th>
                        <th class="tabla_planilla">Lugar</th>
                    </tr>
                    <?php
                        $cantidad = count($ejemplaresJovenCampeonMacho);
                    ?>
                    <?php for($i=0 ; $i < 9 ; $i++): ?>
                    <tr>
                        <?php if($i < $cantidad): ?>
                            <th class="tabla_planilla" id="numero_prefijo"><?php echo e($ejemplaresJovenCampeonMacho[$i]->numero_prefijo); ?></th>
                            <?php
                                $calificaion = App\Juez::ejemplarEventoInscrito($ejemplaresJovenCampeonMacho[$i]->id);
                            ?>
                            <th class="tabla_planilla" id="calificaion"><?php echo e(($calificaion)? $calificaion->calificacion : ''); ?></th>
                            <th class="tabla_planilla"><?php echo e(($calificaion)? $calificaion->lugar : ''); ?></th>
                        <?php else: ?>
                            <th class="tabla_planilla" id="numero_prefijo"><p style="padding-top: 1px;"></p></th>
                            <th class="tabla_planilla" id="calificaion"></th>
                            <th class="tabla_planilla"></th>
                        <?php endif; ?>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CJCGB
                        <table id="tabla-ponderacion" class="tabla_planilla">
                            <thead  class="tabla_planilla">
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
        
        <div id="table-intermedio">
            <table>
                <thead id="tabla-datos" class="tabla_planilla">
                    <tr>
                        <th colspan="3">INTERMEDIA <br> 15 a 24 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo" class="tabla_planilla">
                    <tr>
                        <th class="tabla_planilla">Nº</th>
                        <th class="tabla_planilla">Calf.</th>
                        <th class="tabla_planilla">Lugar</th>
                    </tr>
                    <?php
                        $cantidad = count($ejemplaresIntermediaMacho);
                    ?>
                    <?php for($i=0 ; $i < 9 ; $i++): ?>
                    <tr>
                        <?php if($i < $cantidad): ?>
                            <th class="tabla_planilla" id="numero_prefijo"><?php echo e($ejemplaresIntermediaMacho[$i]->numero_prefijo); ?></th>
                            <?php
                                $calificaion = App\Juez::ejemplarEventoInscrito($ejemplaresIntermediaMacho[$i]->id);
                            ?>
                            <th class="tabla_planilla" id="calificaion"><?php echo e(($calificaion)? $calificaion->calificacion : ''); ?></th>
                            <th class="tabla_planilla"><?php echo e(($calificaion)? $calificaion->lugar : ''); ?></th>
                        <?php else: ?>
                            <th class="tabla_planilla" id="numero_prefijo"><p style="padding-top: 1px;"></p></th>
                            <th class="tabla_planilla" id="calificaion"></th>
                            <th class="tabla_planilla"></th>
                        <?php endif; ?>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot class="tabla_planilla">
                    <td colspan="3" style="height: 47px"></td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-abierta">
            <table class="tabla_planilla">
                <thead id="tabla-datos" class="tabla_planilla">
                    <tr>
                        <th colspan="3">ABIERTA <br> Mayor a 24 Meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo" class="tabla_planilla">
                    <tr>
                        <th class="tabla_planilla">Nº</th>
                        <th class="tabla_planilla">Calf.</th>
                        <th class="tabla_planilla">Lugar</th>
                    </tr>
                    <?php
                        $cantidad = count($ejemplaresAbiertaMacho);
                    ?>
                    <?php for($i=0 ; $i < 9 ; $i++): ?>
                    <tr>
                        <?php if($i < $cantidad): ?>
                            <th class="tabla_planilla" id="numero_prefijo"><?php echo e($ejemplaresAbiertaMacho[$i]->numero_prefijo); ?></th>
                            <?php
                                $calificaion = App\Juez::ejemplarEventoInscrito($ejemplaresAbiertaMacho[$i]->id);
                            ?>
                            <th class="tabla_planilla" id="calificaion"><?php echo e(($calificaion)? $calificaion->calificacion : ''); ?></th>
                            <th class="tabla_planilla"><?php echo e(($calificaion)? $calificaion->lugar : ''); ?></th>
                        <?php else: ?>
                            <th class="tabla_planilla" id="numero_prefijo"><p style="padding-top: 1px;"></p></th>
                            <th class="tabla_planilla" id="calificaion"></th>
                            <th class="tabla_planilla"></th>
                        <?php endif; ?>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>
                    <td colspan="3" style="height: 47px"></td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-campeones">
            <table class="tabla_planilla">
                <thead id="tabla-datos" class="tabla_planilla">
                    <tr>
                        <th id="cabecera-campeones" colspan="3">CAMPEONES</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo" class="tabla_planilla">
                    <tr>
                        <th class="tabla_planilla">Nº</th>
                        <th class="tabla_planilla">Calf.</th>
                        <th class="tabla_planilla">Lugar</th>
                    </tr>
                    <?php
                        $cantidad = count($ejemplaresCampeonesMacho);
                    ?>
                    <?php for($i=0 ; $i < 9 ; $i++): ?>
                    <tr>
                        <?php if($i < $cantidad): ?>
                            <th class="tabla_planilla" id="numero_prefijo"><?php echo e($ejemplaresCampeonesMacho[$i]->numero_prefijo); ?></th>
                            <?php
                                $calificaion = App\Juez::ejemplarEventoInscrito($ejemplaresCampeonesMacho[$i]->id);
                            ?>
                            <th class="tabla_planilla" id="calificaion"><?php echo e(($calificaion)? $calificaion->calificacion : ''); ?></th>
                            <th class="tabla_planilla"><?php echo e(($calificaion)? $calificaion->lugar : ''); ?></th>
                        <?php else: ?>
                            <th class="tabla_planilla" id="numero_prefijo"><p style="padding-top: 1px;"></p></th>
                            <th class="tabla_planilla" id="calificaion"></th>
                            <th class="tabla_planilla"></th>
                        <?php endif; ?>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CGCB
                        <table id="tabla-ponderacion" class="tabla_planilla">
                            <thead  class="tabla_planilla">
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-grandesCampeones">
            <table class="tabla_planilla">
                <thead id="tabla-datos" class="tabla_planilla">
                    <tr>
                        <th id="cabecera-campeones"  colspan="3">GRANDES CAMPEONES</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo" class="tabla_planilla">
                    <tr>
                        <th class="tabla_planilla">Nº</th>
                        <th class="tabla_planilla">Calf.</th>
                        <th class="tabla_planilla">Lugar</th>
                    </tr>
                    <?php
                        $cantidad = count($ejemplaresGrandesCampeoesMacho);
                    ?>
                    <?php for($i=0 ; $i < 9 ; $i++): ?>
                    <tr>
                        <?php if($i < $cantidad): ?>
                            <th class="tabla_planilla" id="numero_prefijo"><?php echo e($ejemplaresGrandesCampeoesMacho[$i]->numero_prefijo); ?></th>
                            <?php
                                $calificaion = App\Juez::ejemplarEventoInscrito($ejemplaresGrandesCampeoesMacho[$i]->id);
                            ?>
                            <th class="tabla_planilla" id="calificaion"><?php echo e(($calificaion)? $calificaion->calificacion : ''); ?></th>
                            <th class="tabla_planilla"><?php echo e(($calificaion)? $calificaion->lugar : ''); ?></th>
                        <?php else: ?>
                            <th class="tabla_planilla" id="numero_prefijo"><p style="padding-top: 1px;"></p></th>
                            <th class="tabla_planilla" id="calificaion"></th>
                            <th class="tabla_planilla"></th>
                        <?php endif; ?>
                    </tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>
                    <td colspan="3" style="height: 47px"></td>
                </tfoot>
            </table>
        </div>
    
        
    </div>

    <div class="planillaHembra">

        <div id="hembra">
            <h3>
                <span> A </span>
                <span> R </span>
                <span> B </span>
                <span> M </span>
                <span> E </span>
                <span> H </span>
            </h3>
        </div>

        <div id="table-cachorrosHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th colspan="3">CACHORRO <br> 6 a 9 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CACV
                        <table id="tabla-ponderacion">
                            <thead >
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-jovenHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th colspan="3">JOVEN <br> 9 a 18 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CACV
                        <table id="tabla-ponderacion">
                            <thead >
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-jovenCampeonHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th colspan="3">JOVEN CAMPEON <br> 9 a 18 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CACV
                        <table id="tabla-ponderacion">
                            <thead >
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
        
        <div id="table-intermedioHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th colspan="3">INTERMEDIA <br> 15 a 24 meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="height: 47px"></td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-abiertaHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th colspan="3">ABIERTA <br> Mayor a 24 Meses</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="height: 47px"></td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-campeonesHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th id="cabecera-campeones"  colspan="3">CAMPEONES</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CACV
                        <table id="tabla-ponderacion">
                            <thead >
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-grandesCampeonesHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th  id="cabecera-campeones"  colspan="3">GRANDES CAMPEONES</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="height: 47px"></td>
                </tfoot>
            </table>
        </div>
    
        <div id="table-veteranosHembra">
            <table>
                <thead id="tabla-datos">
                    <tr>
                        <th  id="cabecera-campeones"  colspan="3">VETERANOS</th>
                    </tr>
                </thead>
                <tbody id="tabla-datos-cuerpo">
                    <tr>
                        <th>Nº</th>
                        <th>Calf.</th>
                        <th>Lugar</th>
                    </tr>
                    
                    
                </tbody>
                <tfoot>
                    <td colspan="3" style="font-size: 10px;">
                        CACV
                        <table id="tabla-ponderacion">
                            <thead >
                                <tr>
                                    <th id="tabla-dentroTabla">N</th>
                                </tr>
                            </thead>
                            <tbody >
                                <tr>
                                    <td id="tabla-dentroTablaponderacion"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tfoot>
            </table>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\laragon\www\kcb\resources\views/juez/planilla.blade.php ENDPATH**/ ?>