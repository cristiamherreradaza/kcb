<table class="table table-striped">
    <thead>
        <tr>
            <th>FECHA</th>
            <th>TITULO</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $titulosEjemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($te->fecha_obtencion); ?></td>
            <td><?php echo e($te->titulo->nombre); ?></td>
            <td>
                <button type="button" class="btn btn-sm btn-icon btn-danger" onclick="eliminaTitulo('<?php echo e($te->id); ?>', '<?php echo e($te->titulo->nombre); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>No tiene examenes</h3>
        <?php endif; ?>
    </tbody>
</table>    
<a href="#" class="btn btn-info btn-block" onclick="nuevoTitulo()">Nuevo Titulo</a><?php /**PATH C:\laragon\www\kcb\resources\views/ejemplar/ajaxGuardaTitulo.blade.php ENDPATH**/ ?>