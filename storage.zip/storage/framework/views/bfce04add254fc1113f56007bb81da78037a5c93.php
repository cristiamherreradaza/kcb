<link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">


<table class="table table-bordered table-hover table-striped" id="tabla_permisos">
    <thead>
        <tr>
            <th>ID</th>
            <th>MENU</th>
            <th>ESTADO</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($p->menu): ?>
                <tr>
                    <td><?php echo e($p->id); ?></td>
                    <td><?php echo e($p->menu->nombre); ?></td>
                    <td>
                        <?php if($p->estado == 'Visible'): ?>
                            <button type="button" class="btn btn-sm  btn-success" onclick="cambiaEstado('<?php echo e($p->id); ?>','<?php echo e($p->perfil_id); ?>')">
                                <?php echo e(($p->estado)); ?>

                            </button>    
                        <?php else: ?>
                            <button type="button" class="btn btn-sm  btn-danger" onclick="cambiaEstado('<?php echo e($p->id); ?>','<?php echo e($p->perfil_id); ?>')">
                                <?php echo e(($p->estado)); ?>

                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3 class="text-danger">NO EXISTEN USUARIOS</h3>
        <?php endif; ?>
    </tbody>
    <tbody>
    </tbody>
</table>

<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<script>
    $('#tabla_permisos').DataTable({
        order: [[ 0, "asc" ]],
        // order: [[ 0, "desc" ]],
        searching: false,
        lengthChange: false,
        language: {
            url: '<?php echo e(asset('datatableEs.json')); ?>'
        },
    });
</script>
<?php /**PATH C:\laragon\www\kcb\resources\views/user/ajaxBuscaPerfil.blade.php ENDPATH**/ ?>