<hr>
<h2 class="text-success text-center">Asignacion</h2>
<table class="table table-striped">
    <thead>
        <tr>
            <th>JUEZ</th>
            <th>SECRETARIO</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $asiganaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($asig->juez->nombre); ?></td>
            <td><?php echo e($asig->secretario->name); ?></td>
            <td>
                <button type="button" class="btn btn-icon btn-danger" onclick="eliminaAsigancion('<?php echo e($asig->id); ?>', '<?php echo e($asig->juez->nombre); ?>')">
                    <i class="flaticon2-cross"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="text-danger">No tiene Jueces Asginados</h3>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\kcb\resources\views/evento/ajaxListadoAsignacion.blade.php ENDPATH**/ ?>