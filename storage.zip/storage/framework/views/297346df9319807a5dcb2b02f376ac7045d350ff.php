

<?php $__env->startSection('metadatos'); ?>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	
	<!-- Modal-->
	<div class="modal fade" id="modal-registro-criadero" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">AGREGAR UN NUEVO CRIADERO</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<i aria-hidden="true" class="ki ki-close"></i>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?php echo e(url('Criadero/guardaCriaderoNuevoPropietario')); ?>" method="POST" id="formulario-agrega-criadero-nuevo-propietario">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="exampleInputPassword1">Propietario
									<span class="text-danger">*</span></label>
									
									<select class="form-control" id="propietario_id" name="propietario_id" required >
										<option value="<?php echo e($propietario->id); ?>"><?php echo e($propietario->name); ?></option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="exampleInputPassword1">Co-Propietario
									<span class="text-danger">*</span></label>
									<div id="select-copropietario">
										<select class="form-control select2" id="copropietario_id" name="copropietario_id" required >
											<option label="Label"></option>
										</select>    
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="exampleInputPassword1">Nombre</label>
									<input type="text" class="form-control" id="nombre" name="nombre"  required  />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Registro FCI
									<span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="registro_fci" name="registro_fci" required  />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Departamento
									<span class="text-danger">*</span></label>
									<select name="departamento" id="departamento" class="form-control"  required >
										<option value="La Paz">La Paz</option>
										<option value="Oruro" >Oruro</option>
										<option value="Potosi" >Potosi</option>
										<option value="Cochabamba" >Cochabamba</option>
										<option value="Chuquisaca" >Chuquisaca</option>
										<option value="Tarija" >Tarija</option>
										<option value="Pando" >Pando</option>
										<option value="Beni" >Beni</option>
										<option value="Santa Cruz">Santa Cruz</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Fecha
									<span class="text-danger">*</span></label>
									<input type="date" class="form-control" name="fecha" id="fecha" required >
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Modalidad de Ingreso
									<span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="modalidad_ingreso" name="modalidad_ingreso"   required />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Direccion
									<span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="direccion" name="direccion"  required  />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Celulares
									<span class="text-danger">*</span></label>
									<input type="text" class="form-control" id="celulares" name="celulares"  required  />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Pagina Web
									
									<input type="text" class="form-control" id="pagina_web" name="pagina_web"  />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="exampleInputPassword1">Email
										<span class="text-danger">*</span></label>
									<input type="email" class="form-control" id="email" name="email"  />
								</div>
							</div>
						</div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-sm btn-light-dark font-weight-bold" data-dismiss="modal">Cerrar</button>
					<button type="button" class="btn btn-sm btn-success font-weight-bold" onclick="agregarProtietarioCriadero()">Guardar</button>
				</div>
			</div>
		</div>
	</div> 
	

	
	<!-- Modal-->
	<div class="modal fade" id="modal-agregar-criadero" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">AGREGAR UN NUEVO CRIADERO</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<i aria-hidden="true" class="ki ki-close"></i>
					</button>
				</div>
				<div class="modal-body">
					<form action="<?php echo e(url('Criadero/guardaCriaderoPropietario')); ?>" method="POST" id="formulario-agrega-criadero-propietario">
						<?php echo csrf_field(); ?>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="exampleInputPassword1">Propietario
									<span class="text-danger">*</span></label>
									<select name="propietario_id" id="propietario_id" class="form-control" required>
										<option value="<?php echo e($propietario->id); ?>"><?php echo e($propietario->name); ?></option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="exampleInputPassword1">Criadero
									<span class="text-danger">*</span></label>
									<input type="hidden" id="criadero_id" name="criadero_id">
									<input type="text" class="form-control" id="criadero" name="criadero" required disabled/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="exampleInputPassword1">Buscar Criadero por Nombre
										<span class="text-danger">*</span>
										<span class="label label-success label-inline font-weight-normal mr-2" onclick="registroNuevoCriadero()">NUEVO</span>
									</label>
									<input type="text" class="form-control" id="busca-criadero-nombre" name="busca-criadero-nombre" />
									<span class="form-text text-danger" id="msg-error-criadero" style="display: none;">Debe seleccionar un Criadero</span>
								</div>
							</div>
						</div>
					</form>
					<div class="row">
						<div class="col-md-12">
							<div id="bloqueCriadero">

							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-sm btn-light-dark font-weight-bold" data-dismiss="modal">Cerrar</button>
					<button type="button" class="btn btn-sm btn-success font-weight-bold" onclick="agregarEjemplarCriadero()">Guardar</button>
				</div>
			</div>
		</div>
	</div> 
	

	<!--begin::Card-->
	<div class="card card-custom gutter-b">
		<div class="card-header flex-wrap py-3">
			<div class="card-title">
				<h3 class="card-label">LISTA DE CRIADEROS DEL PROPIETARIO <span class="text-primary"><?php echo e($propietario->name); ?></span>
				</h3>
			</div>
			<div class="card-toolbar">
				<!--begin::Button-->
				<a href="#" class="btn btn-primary font-weight-bolder" onclick="nuevo()">
					<i class="fa fa-plus-square"></i> NUEVO CRIADERO
				</a>
				<!--end::Button-->
			</div>
		</div>
		
		<div class="card-body">
			<!--begin: Datatable-->
			<div class="table-responsive m-t-40">
                <table class="table table-bordered table-hover table-striped" id="tabla_usuarios">
                    <thead>
						<tr>
							<th>ID</th>
							<th>Nombre</th>
							<th>Regsitro FCI</th>
							<th>Departamento</th>
							<th>Fecha</th>
							<th>Modalidad</th>
							<th>Direccion</th>
							<th>Celulares</th>
							<th>Pagina Web</th>
							<th>Email</th>
							
							
						</tr>
					</thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $criaderos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($cri->id); ?></td>
                                <td><?php echo e($cri->criadero->nombre); ?></td>
                                <td><?php echo e($cri->criadero->registro_fci); ?></td>
                                <td><?php echo e($cri->criadero->departamento); ?></td>
                                <td><?php echo e($cri->criadero->fecha); ?></td>
                                <td><?php echo e($cri->criadero->modalidad_ingreso); ?></td>
                                <td><?php echo e($cri->criadero->direccion); ?></td>
                                <td><?php echo e($cri->criadero->celulares); ?></td>
                                <td><?php echo e($cri->criadero->pagina_web); ?></td>
                                <td><?php echo e($cri->criadero->email); ?></td>
                                
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            No TIENE CRIADEROS
                        <?php endif; ?>
                    </tbody>
                </table>
			</div>
			<!--end: Datatable-->
		</div>
	</div>
	<!--end::Card-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
    <script type="text/javascript">
		$(function () {
			$('#tabla_usuarios').DataTable({
				language: {
					url: '<?php echo e(asset('datatableEs.json')); ?>'
				},
			});

    	});

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		function nuevo()
    	{

			$("#modal-agregar-criadero").modal('show');
			// alert("En desarrollo :v");
			// window.location.href = "<?php echo e(url('User/formulario')); ?>/0";
    	}

		function elimina(id, nombre)
        {
            Swal.fire({
                title: "Quieres eliminar "+nombre,
                text: "Ya no podras recuperarlo!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Si, borrar!",
                cancelButtonText: "No, cancelar!",
                reverseButtons: true
            }).then(function(result) {
                if (result.value) {
                    window.location.href = "<?php echo e(url('User/elimina')); ?>/"+id;
                    Swal.fire(
                        "Borrado!",
                        "El registro fue eliminado.",
                        "success"
                    )
                    // result.dismiss can be "cancel", "overlay",
                    // "close", and "timer"
                } else if (result.dismiss === "cancel") {
                    Swal.fire(
                        "Cancelado",
                        "La operacion fue cancelada",
                        "error"
                    )
                }
            });
        }

		$("#busca-criadero-nombre").on("paste keyup", function() {

			let nombre = $("#busca-criadero-nombre").val();

			$.ajax({
				url: "<?php echo e(url('Criadero/ajaxBuscaCriaderoPropietario')); ?>",
				data:{
					nombre:nombre
				},
				type: 'POST',
				success: function(data) {
					$("#bloqueCriadero").html(data);
				}
			});
		});

		function agregarEjemplarCriadero(){
			if($("#criadero").val() != '' ){
				$('#formulario-agrega-criadero-propietario').submit();
			}else{
				$("#msg-error-criadero").show();
			}
		}

		function registroNuevoCriadero(){
			$("#modal-agregar-criadero").modal('hide');
			$("#modal-registro-criadero").modal('show');
			// alert("en desarrollo :v");
		}

		$("#copropietario_id").select2({
			placeholder: "Busca por nombre",
			allowClear: true,
			ajax: {
				url: "<?php echo e(url('User/ajaxBuscaPropietario')); ?>",
				dataType: 'json',
				method: 'POST',
				delay: 250,
				data: function (params) {
					return {
						search: params.term,
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				},
				cache: true
			},
			minimumInputLength: 1,
		});

		function agregarProtietarioCriadero(){
			if($('#formulario-agrega-criadero-nuevo-propietario')[0].checkValidity()){
				$('#formulario-agrega-criadero-nuevo-propietario').submit();
				Swal.fire("Excelente!", "Ejemplar Guardado!", "success");
			}else{
				$('#formulario-agrega-criadero-nuevo-propietario')[0].reportValidity()
			}
			// alert("en desarrollo :v");
		}
	
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/user/listadoCriadero.blade.php ENDPATH**/ ?>