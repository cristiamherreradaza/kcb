

<?php $__env->startSection('content'); ?>

<!--begin::Card-->
<div class="card card-custom gutter-b">
    <div class="card-header flex-wrap py-3">
        <div class="card-title">
            <h3 class="card-label">LISTADO DE CAMBIOS
            </h3>
        </div>
        <div class="card-toolbar">
            <!--begin::Button-->
            
            <!--end::Button-->
        </div>
    </div>
    <div class="card-body">

        <div class="row">
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Examenes Asignados</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped">
                            <tr>
                                <th>FECHA</th>
                                <th>EXAMEN</th>
                                <th>ASIGNADO POR</th>
                            </tr>
                            <?php $__currentLoopData = $examenEjemplarAsignacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ea->fecha_examen); ?></td>
                                    <td><?php echo e($ea->examen->nombre); ?></td>
                                    <td>
                                        <?php echo e($ea->asignador->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Tramsferencias Asignados</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped">
                            <tr>
                                <th>FECHA</th>
                                <th>PROPIETARIO</th>
                                <th>ASIGNADO POR</th>
                            </tr>
                            <?php $__currentLoopData = $transferenciaEjemplarAsignacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ta->fecha_transferencia); ?></td>
                                    <td><?php echo e($ta->propietario->name); ?></td>
                                    <td>
                                        <?php echo e($ta->asignador->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Titulos Asignados</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped">
                            <tr>
                                <th>FECHA</th>
                                <th>TITULO</th>
                                <th>ASIGNADO POR</th>
                            </tr>
                            <?php $__currentLoopData = $tituloEjemplarAsignacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tia->fecha_obtencion); ?></td>
                                    <td><?php echo e($tia->titulo->nombre); ?></td>
                                    <td>
                                        <?php echo e($tia->asignador->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="separator separator-dashed separator-border-2 separator-primary"></div>
        <h1>&nbsp;</h1>
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center">Listado de Modificaiones</h1>
            </div>
        </div>
        <br>
        <?php $__empty_1 = true; $__currentLoopData = $modificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $original = json_decode($m->original, true);
                $modificacion = json_decode($m->cambio, true);
                $utilidades = new App\librerias\Utilidades();
                $fechaHoraEs = $utilidades->fechaHoraCastellano($m->created_at);
            ?>
            <div class="row">
                <div class="col-md-4">
                    <h3><span class="text-primary">Usuario: </span> 
                        <?php
                            $user = App\User::find($m->user_id);
                            echo $user->name;
                        ?>    
                    </h3>
                </div>
                <div class="col-md-8">

                    <h3><span class="text-primary">Fecha Hora: </span> <?php echo e($fechaHoraEs); ?></h3>
                </div>
            </div>
            
            <table class="table table-bordered table-hover table-striped" id="tabla_criaderos">
                <thead>
                    <tr>
                        <th>Campo</th>
                        <th>Original</th>
                        <th>Modificacion</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if($original['kcb'] == $modificacion['kcb']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>

                    <tr <?php echo $estilo; ?>>
                        <td>KCB</td>
                        <td><?php echo e($original['kcb']); ?></td>
                        <td><?php echo e($modificacion['kcb']); ?></td>
                    </tr>
                    <?php
                        if($original['nombre'] == $modificacion['nombre']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>NOMBRE</td>
                        <td><?php echo e($original['nombre']); ?></td>
                        <td><?php echo e($modificacion['nombre']); ?></td>
                    </tr>
                    <?php
                        if($original['padre_id'] == $modificacion['padre_id']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                        $padreOriginal = App\Ejemplar::find($original['padre_id']);
                        $padreModificado = App\Ejemplar::find($modificacion['padre_id']);
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>PADRE</td>
                        <td><?php echo e(($padreOriginal)? $padreOriginal->nombre_completo:''); ?></td>
                        <td><?php echo e(($padreModificado)? $padreModificado->nombre_completo:''); ?></td>
                    </tr>
                    <?php
                        if($original['madre_id'] == $modificacion['madre_id']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                        $madreOriginal = App\Ejemplar::find($original['madre_id']);
                        $madreModificado = App\Ejemplar::find($modificacion['madre_id']);
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>MADRE</td>
                        <td><?php echo e(($madreOriginal)? $madreOriginal->nombre_completo:''); ?></td>
                        <td><?php echo e(($madreModificado)? $madreModificado->nombre_completo:''); ?></td>
                    </tr>
                    <?php
                        if($original['raza_id'] == $modificacion['raza_id']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                        $razaOriginal = App\Raza::find($original['raza_id']);
                        $razaModificado = App\Raza::find($modificacion['raza_id']);
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>RAZA</td>
                        <td><?php echo e(($razaOriginal)? $razaOriginal->nombre:''); ?></td>
                        <td><?php echo e(($razaModificado)? $razaModificado->nombre:''); ?></td>
                    </tr>
                    
                    <?php
                        if($original['criadero_id'] == $modificacion['criadero_id']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                        $criaderoOriginal = App\Criadero::find($original['criadero_id']);
                        $criaderoModificado = App\Criadero::find($modificacion['criadero_id']);
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>CRIADERO</td>
                        <td><?php echo e(($criaderoOriginal)? $criaderoOriginal->nombre:''); ?></td>
                        <td><?php echo e(($criaderoModificado)? $criaderoModificado->nombre:''); ?></td>
                    </tr>
                    <?php
                        if($original['propietario_id'] == $modificacion['propietario_id']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                        $propietarioOriginal = App\User::find($original['propietario_id']);
                        $propietarioModificado = App\User::find($modificacion['propietario_id']);
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>PROPIETARIO</td>
                        <td><?php echo e(($propietarioOriginal)? $propietarioOriginal->name:''); ?></td>
                        <td><?php echo e(($propietarioModificado)? $propietarioModificado->name:''); ?></td>
                    </tr>
                    
                    <?php
                        if($original['codigo_nacionalizado'] == $modificacion['codigo_nacionalizado']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>CODIGO NACIONALIZADO</td>
                        <td><?php echo e($original['codigo_nacionalizado']); ?></td>
                        <td><?php echo e($modificacion['codigo_nacionalizado']); ?></td>
                    </tr>
                    
                    <?php
                        if($original['num_tatuaje'] == $modificacion['num_tatuaje']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>TATUAJE</td>
                        <td><?php echo e($original['num_tatuaje']); ?></td>
                        <td><?php echo e($modificacion['num_tatuaje']); ?></td>
                    </tr>
                    <?php
                        if($original['chip'] == $modificacion['chip']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>CHIP</td>
                        <td><?php echo e($original['chip']); ?></td>
                        <td><?php echo e($modificacion['chip']); ?></td>
                    </tr>
                    <?php
                        if($original['fecha_nacimiento'] == $modificacion['fecha_nacimiento']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>FECHA NACIMIENTO</td>
                        <td><?php echo e($original['fecha_nacimiento']); ?></td>
                        <td><?php echo e($modificacion['fecha_nacimiento']); ?></td>
                    </tr>
                    <?php
                        if($original['color'] == $modificacion['color']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>COLOR</td>
                        <td><?php echo e($original['color']); ?></td>
                        <td><?php echo e($modificacion['color']); ?></td>
                    </tr>
                    <?php
                        if($original['senas'] == $modificacion['senas']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>SEÑAS</td>
                        <td><?php echo e($original['senas']); ?></td>
                        <td><?php echo e($modificacion['senas']); ?></td>
                    </tr>
                    
                    <?php
                        if($original['lechigada'] == $modificacion['lechigada']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>LECHIGADA</td>
                        <td><?php echo e($original['lechigada']); ?></td>
                        <td><?php echo e($modificacion['lechigada']); ?></td>
                    </tr>
                    <?php
                        if($original['sexo'] == $modificacion['sexo']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>SEXO</td>
                        <td><?php echo e($original['sexo']); ?></td>
                        <td><?php echo e($modificacion['sexo']); ?></td>
                    </tr>
                    
                    
                    
                    
                    <?php
                        if($original['consanguinidad'] == $modificacion['consanguinidad']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>CONSANGUINIDAD</td>
                        <td><?php echo e($original['consanguinidad']); ?></td>
                        <td><?php echo e($modificacion['consanguinidad']); ?></td>
                    </tr>
                    <?php
                        if($original['hermano'] == $modificacion['hermano']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>HERMANOS</td>
                        <td><?php echo e($original['hermano']); ?></td>
                        <td><?php echo e($modificacion['hermano']); ?></td>
                    </tr>
                    <?php
                        if($original['departamento'] == $modificacion['departamento']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>DEPARTAMENTO</td>
                        <td><?php echo e($original['departamento']); ?></td>
                        <td><?php echo e($modificacion['departamento']); ?></td>
                    </tr>
                    
                    <?php
                        if($original['fecha_fallecido'] == $modificacion['fecha_fallecido']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>FECHA FALLECIDO</td>
                        <td><?php echo e($original['fecha_fallecido']); ?></td>
                        <td><?php echo e($modificacion['fecha_fallecido']); ?></td>
                    </tr>
                    <?php
                        if($original['fecha_emision'] == $modificacion['fecha_emision']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>FECHA DE EMISION</td>
                        <td><?php echo e($original['fecha_emision']); ?></td>
                        <td><?php echo e($modificacion['fecha_emision']); ?></td>
                    </tr>
                    <?php
                        if($original['fecha_nacionalizado'] == $modificacion['fecha_nacionalizado']){
                            $estilo = 'class="table-success"';
                        }else{
                            $estilo = 'class="table-danger"';
                        }
                    ?>
                    <tr <?php echo $estilo; ?>>
                        <td>FECHA NACIONALIZADO</td>
                        <td><?php echo e($original['fecha_nacionalizado']); ?></td>
                        <td><?php echo e($modificacion['fecha_nacionalizado']); ?></td>
                    </tr>
                </tbody>                
            </table>
            <div class="separator separator-dashed separator-border-2 separator-primary"></div>
            <h1>&nbsp;</h1>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Examenes Eliminados</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped">
                            <tr>
                                <th>FECHA</th>
                                <th>EXAMEN</th>
                                <th>ELIMINADO POR</th>
                            </tr>
                            <?php $__currentLoopData = $examenEjemplar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($e->fecha_examen); ?></td>
                                    <td><?php echo e($e->examen->nombre); ?></td>
                                    <td>
                                        <?php echo e($e->userEliminador->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Tramsferencias Eliminados</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped">
                            <tr>
                                <th>FECHA</th>
                                <th>PROPIETARIO</th>
                                <th>ELIMINADO POR</th>
                            </tr>
                            <?php $__currentLoopData = $transferenciaEjemplar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($t->fecha_transferencia); ?></td>
                                    <td><?php echo e($t->propietario->name); ?></td>
                                    <td>
                                        <?php echo e($t->userEliminador->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Titulos Eliminados</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <table class="table table-striped">
                            <tr>
                                <th>FECHA</th>
                                <th>TITULO</th>
                                <th>ELIMINADO POR</th>
                            </tr>
                            <?php $__currentLoopData = $tituloEjemplar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ti->fecha_obtencion); ?></td>
                                    <td><?php echo e($ti->titulo->nombre); ?></td>
                                    <td>
                                        <?php echo e($ti->userEliminador->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
<!--end::Card-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kcb\resources\views/ejemplar/muestraModificacion.blade.php ENDPATH**/ ?>