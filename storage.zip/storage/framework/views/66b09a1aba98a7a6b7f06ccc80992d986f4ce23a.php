<table class="table table-striped">
    <thead>
        <tr>
            <th>NOMBRE</th>
            <th>DEPARTAMENTO</th>
            <th>REGISTRO FCI</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $criaderos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($cri->nombre); ?></td>
                <td><?php echo e($cri->departamento); ?></td>
                <td><?php echo e($cri->registro_fci); ?></td>
                <td>
                    <a href="#" class="btn btn-icon btn-success" onclick="selecciona(`<?php echo e($cri->id); ?>`, `<?php echo e(trim($cri->nombre)); ?>`, `<?php echo e(trim($cri->descripcion)); ?>`);">
                        <i class="fas fa-check"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h6 class="text-danger">NO EXISTEN CRIADEROS CON ESE NOMBRE</h6>
        <?php endif; ?>
    </tbody>
</table>
<script type="text/javascript">
    function selecciona(id, nombre, descripcion)
    {
        $("#criadero").val(nombre);
        $("#criadero_id").val(id);
        $("#busca-criadero-nombre").val('');
        $("#bloqueCriadero").html('');
        $("#msg-error-criadero").hide();
    }
</script><?php /**PATH C:\laragon\www\kcb\resources\views/criaderos/ajaxBuscaCriaderoPropietario.blade.php ENDPATH**/ ?>