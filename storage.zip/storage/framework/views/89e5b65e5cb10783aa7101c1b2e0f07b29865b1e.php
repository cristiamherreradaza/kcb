<div class="row">
    
    <?php
        $cantidadToltal  = $menusPerfiles->count();
        $columnas = 2;
        $canCol = round($cantidadToltal/$columnas);
        $canRes = $cantidadToltal - $canCol;
        $contador = 1;
    // echo $cantidad;

    ?>

    <?php $__currentLoopData = $menusPerfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($contador <= $canCol): ?>
            <?php if($contador == 1): ?>
                <?php if($m->menu): ?>
                <div class="col-md-6">
                    <?php if($m->menu->direccion!='#'): ?>
                        <br>- <input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                    <?php else: ?>
                        <br><input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                    <?php endif; ?>
                <?php endif; ?>
            <?php else: ?>
                <?php if($contador==$canCol): ?>
                    <?php if($m->menu): ?>
                        <?php if($m->menu->direccion!='#'): ?>
                                <br>- <input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                            </div>
                        <?php else: ?>
                                <br><input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                            </div>
                        <?php endif; ?>    
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($m->menu): ?>
                        <?php if($m->menu->direccion!='#'): ?>
                            <br>- <input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                        <?php else: ?>
                            <br><input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                        <?php endif; ?>    
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
            <?php if($contador==($canCol+1)): ?>
                <?php if($m->menu): ?>
                    <div class="col-md-6">
                        <?php if($m->menu->direccion!='#'): ?>
                            <br>- <input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label>         
                        <?php else: ?>
                            <br><input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label>         
                        <?php endif; ?>    
                <?php endif; ?>
            <?php else: ?>
                <?php if($contador==$cantidadToltal): ?>
                    <?php if($m->menu): ?>
                            <?php if($m->menu->direccion!='#'): ?>
                                <br>- <input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                            <?php else: ?>
                                <br><input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label> 
                            <?php endif; ?>    
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($m->menu): ?>
                        <?php if($m->menu->direccion!='#'): ?>
                            <br>- <input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label>         
                        <?php else: ?>
                            <br><input type="checkbox" id="<?php echo e($m->id); ?>" onchange="guarda('<?php echo e($m->id); ?>')" <?php echo e(($m->estado=='Visible')? "checked":''); ?> > <label for="<?php echo e($m->id); ?>"><?php echo e($m->menu->nombre); ?></label>         
                        <?php endif; ?>    
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
        <?php
            $contador++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\kcb\resources\views/user/ajaxPermisosPerfiles.blade.php ENDPATH**/ ?>