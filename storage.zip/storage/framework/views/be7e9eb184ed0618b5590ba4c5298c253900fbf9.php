<form action="">

    <?php $__empty_1 = true; $__currentLoopData = $arrayEjemplaresDevuetos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php
            $arrayRaza = array();
        ?>

        <div class="table-responsive m-t-40">
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr class="text-info text-center">
                        <th colspan="2">
                            <?php
                                if($aed[0]->categoria_pista_id == 1){
                                    $categoria = "Especial";
                                }elseif($aed[0]->categoria_pista_id == 11 || $aed[0]->categoria_pista_id == 2){
                                    $categoria = "Absoluto";
                                }elseif($aed[0]->categoria_pista_id == 3 || $aed[0]->categoria_pista_id == 4 || $aed[0]->categoria_pista_id == 12 || $aed[0]->categoria_pista_id == 13){
                                    $categoria = "Jovenes";
                                }elseif($aed[0]->categoria_pista_id == 5 || $aed[0]->categoria_pista_id == 6 || $aed[0]->categoria_pista_id == 7 || $aed[0]->categoria_pista_id == 8 || $aed[0]->categoria_pista_id == 9 || $aed[0]->categoria_pista_id == 10 || $aed[0]->categoria_pista_id == 14 || $aed[0]->categoria_pista_id == 15 || $aed[0]->categoria_pista_id == 16 || $aed[0]->categoria_pista_id == 17 || $aed[0]->categoria_pista_id == 18 || $aed[0]->categoria_pista_id == 19 || $aed[0]->categoria_pista_id == 20){
                                    $categoria = "Adultos";
                                }
                            ?>
                            <span class="text-primary"><?php echo e($categoria); ?></span> -> Grupo -> <span class="text-primary"><?php echo e($aed[0]->grupo_id); ?></span>
                        </th>
                    </tr>
                    <tr>
                        <th width="100px">Numero</th>
                        <th>Calificacion</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $aed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(!in_array($ed->raza_id,$arrayRaza)): ?>
                            <tr class="text-center">
                                <td colspan="2">
                                    <h6><?php echo e($ed->raza->nombre); ?></h6>
                                </td>
                            </tr>
                            <?php
                                array_push($arrayRaza,$ed->raza_id);
                            ?>
                        <?php endif; ?>

                        <tr>
                            <td>
                                <h2 class="text-center text-primary">
                                    <?php echo e($ed->numero_prefijo); ?>

                                </h2>
                            </td>
                            <td>
                                <select name="" id="" class="form-control">
                                    <option value="">Bien</option>
                                    <option value="">Muy Bien</option>
                                    <option value="">Excelente</option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3 class="text-danger text-center">Sin datos</h3>
    <?php endif; ?>

    
</form><?php /**PATH C:\laragon\www\kcb\resources\views/juez/AjaxformularioCalificaion.blade.php ENDPATH**/ ?>